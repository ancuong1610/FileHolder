"""Evaluation suite: identity test + synthetic mutation scoring.

Usage:
    python -m crr_compare eval [--seed 42] [--skip-identity]

Two cases run in isolated workspace roots (workspace/eval/<case>/):
  identity - old extraction vs itself: must produce ZERO changes; any
             detected change is a false positive. Duplicate-assignment and
             resegmentation review entries are reported but not failures.
  mutation - old extraction vs a synthetically mutated copy with known
             ground truth: scores precision/recall/F1 per change category.
"""
from __future__ import annotations

import json
import os
import shutil
import time
from pathlib import Path

from crr_compare import cli
from crr_compare.mutations import generate_mutations


def _prepare_case_root(case_root: Path, source_cache: Path, both_from_old: bool) -> None:
    if case_root.exists():
        shutil.rmtree(case_root)
    (case_root / "output").mkdir(parents=True)
    old_chunk = source_cache / "old_crr_2024_01_09" / "chunk_001_pages_0001_0100.json"
    new_chunk = (
        old_chunk
        if both_from_old
        else source_cache / "new_crr_2024_07_09" / "chunk_001_pages_0001_0100.json"
    )
    for doc_dir, source in (
        ("old_crr_2024_01_09", old_chunk),
        ("new_crr_2024_07_09", new_chunk),
    ):
        target = case_root / "cache" / "di_chunks" / doc_dir
        target.mkdir(parents=True)
        shutil.copy(source, target / "chunk_001_pages_0001_0100.json")


def _run_stages(start: str, end: str, root: Path) -> None:
    class Args:
        pass

    args = Args()
    args.from_stage = start
    args.to_stage = end
    cli.run_stages(cli.parse_stage_range(args), root)


def _load_canonical(root: Path) -> dict:
    return json.loads((root / "output" / "comparison_result.json").read_text(encoding="utf-8"))


def _review_composition(canonical: dict) -> dict[str, int]:
    from collections import Counter

    return dict(Counter(item.get("source_kind") for item in canonical.get("review_queue") or []))


def run_identity(workspace_root: Path) -> dict:
    case_root = workspace_root / "eval" / "identity"
    cache = workspace_root / "cache" / "di_chunks"
    print("\n=== IDENTITY CASE (old vs old): expecting zero changes ===")
    _prepare_case_root(case_root, cache, both_from_old=True)
    started = time.perf_counter()
    _run_stages("01", "15", case_root)
    elapsed = round(time.perf_counter() - started, 1)

    canonical = _load_canonical(case_root)
    stats = canonical.get("statistics") or {}
    changes = stats.get("changes", -1)
    table_changes = stats.get("table_changes", -1)
    passed = changes == 0 and table_changes == 0
    result = {
        "case": "identity",
        "passed": passed,
        "elapsed_seconds": elapsed,
        "element_changes": changes,
        "table_changes": table_changes,
        "review_queue_composition": _review_composition(canonical),
    }
    print(json.dumps(result, indent=2))
    if not passed:
        samples = [
            {"id": c["change_id"], "type": c["change_type"], "old": ((c.get("old") or {}).get("text") or "")[:90]}
            for c in canonical.get("changes", [])[:10]
        ]
        print("IDENTITY FAILURE — first false-positive changes:")
        print(json.dumps(samples, indent=2, ensure_ascii=False))
    return result


def run_mutation(workspace_root: Path, seed: int) -> dict:
    case_root = workspace_root / "eval" / "mutation"
    cache = workspace_root / "cache" / "di_chunks"
    print(f"\n=== MUTATION CASE (old vs mutated old), seed={seed} ===")
    _prepare_case_root(case_root, cache, both_from_old=True)

    _run_stages("01", "03", case_root)

    old_model_path = case_root / "output" / "old_document.json"
    model = json.loads(old_model_path.read_text(encoding="utf-8"))
    mutated_model, truth = generate_mutations(model, seed=seed)
    (case_root / "output" / "new_document.json").write_text(
        json.dumps(mutated_model, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    (case_root / "output" / "eval_mutation_truth.json").write_text(
        json.dumps({"seed": seed, "truth": truth}, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    counts = {}
    for entry in truth:
        counts[entry["type"]] = counts.get(entry["type"], 0) + 1
    print("Injected ground-truth mutations:", json.dumps(counts))

    started = time.perf_counter()
    _run_stages("04", "15", case_root)
    elapsed = round(time.perf_counter() - started, 1)

    canonical = _load_canonical(case_root)
    score = _score_mutation_case(canonical, truth)
    score.update({"case": "mutation", "seed": seed, "elapsed_seconds": elapsed})
    print(json.dumps(score["summary"], indent=2))
    if score["false_positives"]:
        print("False positives (cosmetic noise) — first 8:")
        print(json.dumps(score["false_positives"][:8], indent=2, ensure_ascii=False))
    return score


def _score_mutation_case(canonical: dict, truth: list[dict]) -> dict:
    changes = canonical.get("changes") or []
    modified_old, deleted_old, added_new = set(), set(), set()
    fp_candidates: list[dict] = []

    gt_modify = {e["element_id"] for e in truth if e["type"] == "modify"}
    gt_delete = {e["element_id"] for e in truth if e["type"] == "delete"}
    gt_insert = {e["element_id"] for e in truth if e["type"] == "insert"}
    gt_move_ids = {
        eid
        for e in truth
        if e["type"] == "move_block"
        for eid in e["element_ids"]
    }
    gt_cells = {e["cell_id"] for e in truth if e["type"] == "table_cell"}

    reseg_old, reseg_new = set(), set()
    for item in canonical.get("review_queue") or []:
        if item.get("source_kind") != "resegmentation_pair":
            continue
        evidence = item.get("evidence") or {}
        reseg_old.update(evidence.get("old_element_ids") or [])
        reseg_new.update(evidence.get("new_element_ids") or [])

    detected_modified_pairs = []
    for change in changes:
        ctype = change.get("change_type")
        old_id = (change.get("old") or {}).get("element_id")
        new_id = (change.get("new") or {}).get("element_id")
        if ctype == "MODIFIED":
            modified_old.add(old_id)
            detected_modified_pairs.append(change)
        elif ctype == "DELETED":
            deleted_old.add(old_id)
        elif ctype == "ADDED":
            added_new.add(new_id)

    # --- recall per category ---
    modify_hits = gt_modify & modified_old
    modify_degraded = (gt_modify & deleted_old) | (gt_modify & reseg_old)
    delete_hits = gt_delete & deleted_old
    delete_consumed = gt_delete & reseg_old
    insert_hits = gt_insert & added_new
    insert_consumed = gt_insert & reseg_new
    moved_kept = gt_move_ids - deleted_old - added_new - reseg_old - reseg_new

    cell_hit = False
    for record in canonical.get("table_changes") or []:
        for cell in record.get("cell_changes") or []:
            old_cell = (cell.get("old") or {}).get("cell_id")
            new_cell = (cell.get("new") or {}).get("cell_id")
            if old_cell in gt_cells or new_cell in gt_cells:
                if cell.get("classification") != "UNCHANGED":
                    cell_hit = True

    # --- precision: every detection must trace back to a GT mutation ---
    known_old = gt_modify | gt_delete | gt_move_ids
    known_new = gt_insert | gt_move_ids
    fp_modified = [c for c in detected_modified_pairs
                   if (c["old"].get("element_id") not in gt_modify)]
    fp_deleted = [c for c in changes
                  if c.get("change_type") == "DELETED"
                  and (c["old"].get("element_id") not in gt_delete)
                  and (c["old"].get("element_id") not in gt_modify)]
    fp_added = [c for c in changes
                if c.get("change_type") == "ADDED"
                and (c["new"].get("element_id") not in gt_insert)]

    def prf(tp: int, fp: int, fn: int) -> dict:
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 1.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        return {"precision": round(precision, 3), "recall": round(recall, 3), "f1": round(f1, 3)}

    summary = {
        "modify": {
            **prf(len(modify_hits), len(fp_modified), len(gt_modify) - len(modify_hits)),
            "degraded_to_delete_or_reseg": len(modify_degraded),
        },
        "delete": {
            **prf(
                len(delete_hits) + len(delete_consumed) and len(delete_hits) + len(delete_consumed),
                len(fp_deleted),
                len(gt_delete) - len(delete_hits) - len(delete_consumed),
            ),
            "suppressed_by_reseg_review": len(delete_consumed),
        },
        "insert": {
            **prf(
                len(insert_hits) + len(insert_consumed),
                len(fp_added),
                len(gt_insert) - len(insert_hits) - len(insert_consumed),
            ),
            "suppressed_by_reseg_review": len(insert_consumed),
        },
        "move_block": {
            "moved_elements": len(gt_move_ids),
            "kept_paired_not_add_delete": len(moved_kept),
        },
        "table_cell": {"hit": cell_hit},
        "totals": {
            "detected_element_changes": len(changes),
            "false_positives": len(fp_modified) + len(fp_deleted) + len(fp_added),
        },
    }

    def brief(change: dict) -> dict:
        side = change.get("old") if change.get("change_type") != "ADDED" else change.get("new")
        return {
            "id": change.get("change_id"),
            "type": change.get("change_type"),
            "text": (side.get("text") or "")[:80],
        }

    false_positives = [brief(c) for c in (fp_modified + fp_deleted + fp_added)[:20]]
    passed = (
        summary["modify"]["degraded_to_delete_or_reseg"] == 0
        and summary["modify"]["recall"] >= 0.75
        and (len(delete_hits) + len(delete_consumed)) >= len(gt_delete)
        and (len(insert_hits) + len(insert_consumed)) >= len(gt_insert)
        and len(moved_kept) == len(gt_move_ids)
        and cell_hit
        and summary["totals"]["false_positives"] == 0
    )
    return {"summary": summary, "passed": passed, "false_positives": false_positives}


def evaluate_command(root: Path, seed: int, skip_identity: bool) -> None:
    results = []
    if not skip_identity:
        results.append(run_identity(root))
    results.append(run_mutation(root, seed))

    report_path = root / "eval" / "eval_report.json"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"\nSaved eval report: {report_path}")

    overall_passed = all(result.get("passed") for result in results)
    print(f"\nEVALUATION {'PASSED' if overall_passed else 'FAILED'}")
    if not overall_passed:
        raise SystemExit(1)
