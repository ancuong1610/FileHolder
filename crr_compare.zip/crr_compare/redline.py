"""Inline HTML redline renderer (self-contained, print-to-PDF friendly).

Renders the OLD document in reading order with inline change markers:
  <del>old</del><ins>new</ins> for MODIFIED / RESEGMENTATION pairs,
  struck-through blocks for DELETED, inserted blocks for ADDED (placed after
  the nearest preceding matched old position), and changed-table blocks.
Each change carries a comment box: id, type, status and proof.
"""
from __future__ import annotations

import bisect
import html
import json
from pathlib import Path

from crr_compare.common import find_project_root

MAX_INLINE_CHARS = 220

_CSS = """
body{font-family:Georgia,'Times New Roman',serif;margin:0;background:#f4f1ec;color:#222}
header.bar{background:#1f2d3d;color:#fff;padding:14px 28px}
header.bar h1{margin:0;font-size:20px}header.bar p{margin:4px 0 0;font-size:12px;opacity:.85}
main{max-width:1240px;margin:18px auto 60px;background:#fff;padding:34px 40px;box-shadow:0 1px 6px rgba(0,0,0,.15)}
.bucket{font-size:15px;font-weight:bold;color:#1a4d8f;border-bottom:2px solid #1a4d8f;margin:26px 0 10px;padding-bottom:3px}
.row{display:grid;grid-template-columns:minmax(0,2fr) minmax(240px,1fr);gap:18px;align-items:start;margin:8px 0}
.flow p.el{margin:0;line-height:1.6;font-size:14.5px}
p.el.solo{margin:7px 0;line-height:1.55;font-size:14.5px}
p.el.heading{font-weight:bold}
del{color:#c00000;text-decoration:line-through}
ins{color:#c00000;text-decoration:underline}
.cmark{font-family:Menlo,Consolas,monospace;font-size:10.5px;color:#666;background:#f0f0f0;
 border-radius:8px;padding:1px 7px;margin-left:8px;white-space:nowrap}
aside.note{border-top:1.5px solid #333;border-bottom:1px solid #bbb;padding:6px 2px;font-size:11.5px;color:#333}
aside.note h5{margin:0 0 5px;font-size:12px;font-weight:bold;text-decoration:underline;color:#111}
aside.note table{border-collapse:collapse;width:100%}
aside.note td{padding:1px 8px 1px 0;font-size:11px;vertical-align:top}
td.k{color:#777;white-space:nowrap}
details.comment summary{cursor:pointer;color:#1a4d8f;font-weight:bold;font-size:11px}
.tableblock{border:1px solid #ccc;border-radius:4px;margin:12px 0;padding:10px 14px;background:#fbfbf8;font-size:13px}
.tableblock h4{margin:0 0 8px;font-size:12.5px;color:#333}
.cellrow{margin:3px 0;line-height:1.45}
footer.note{max-width:1240px;margin:10px auto 40px;font-size:11px;color:#666;text-align:center}
@media (max-width:900px){.row{grid-template-columns:1fr}}
@media print{body{background:#fff}main{box-shadow:none;margin:0;max-width:none;padding:10mm 12mm}}
"""

from crr_compare.lang_profile import STRUCTURE_BUCKET_PREFIXES as STRUCTURE_PREFIXES


def _esc(text) -> str:
    return html.escape(str(text if text is not None else ""))


def _short(text, limit: int = 90) -> str:
    text = str(text or "")
    return text if len(text) <= limit else text[: limit - 1] + "..."


def load_outputs(root: Path):
    out = root / "output"
    comparison = json.loads((out / "comparison_result.json").read_text(encoding="utf-8"))
    old_doc = json.loads((out / "old_document_structured.json").read_text(encoding="utf-8"))
    new_doc = json.loads((out / "new_document_structured.json").read_text(encoding="utf-8"))
    return comparison, old_doc, new_doc


def resolve_added_anchors(comparison: dict, movement_path: Path, exact_path: Path) -> dict[str, int]:
    """new element_id -> reading_order of nearest preceding matched old element."""
    anchors: list[tuple[int, int]] = []

    def collect(records):
        for rec in records:
            old = rec.get("old") or {}
            new = rec.get("new") or {}
            oro, nro = old.get("reading_order"), new.get("reading_order")
            if isinstance(oro, int) and isinstance(nro, int):
                anchors.append((nro, oro))

    try:
        exact = json.loads(exact_path.read_text(encoding="utf-8"))
        collect(exact.get("matches") or [])
    except FileNotFoundError:
        pass
    try:
        movement = json.loads(movement_path.read_text(encoding="utf-8"))
        for group in ("modified", "modified_review", "duplicate_exact_review", "relocated"):
            collect(movement.get(group) or [])
        collect(movement.get("resegmentation_review") or [])
    except FileNotFoundError:
        pass

    anchors.sort()
    new_ros = [nro for nro, _ in anchors]

    resolved: dict[str, int] = {}
    for change in comparison.get("changes") or []:
        if change.get("change_type") != "ADDED":
            continue
        new = change.get("new") or {}
        nro = new.get("reading_order")
        if not isinstance(nro, int):
            continue
        idx = bisect.bisect_left(new_ros, nro)
        resolved[new.get("element_id")] = anchors[idx - 1][1] if idx > 0 else -1
    return resolved


def comment_rows(item: dict, extra_rows: list[tuple[str, str]] | None = None) -> str:
    resolution = item.get("resolution") or {}
    status = resolution.get("status", "?")
    rows: list[tuple[str, str]] = [
        ("ID", _esc(item.get("change_id") or item.get("candidate_id") or "-")),
        ("Typ", _esc(item.get("change_type") or "-")),
        ("Status", f"{_esc(status)} ({'Review' if item.get('needs_review') else 'automatisch'})"),
    ]
    if item.get("similarity") is not None:
        rows.append(("Ähnlichkeit", round(item["similarity"], 4)))
    reasons = item.get("review_reasons") or []
    if reasons:
        rows.append(("Gründe", _esc(", ".join(reasons))))
    rows.extend((k, v) for k, v in (extra_rows or []))
    return "".join(f"<tr><td class='k'>{k}:</td><td>{v}</td></tr>" for k, v in rows)


def note_box(item: dict, heading: str, extra_rows: list[tuple[str, str]] | None = None) -> str:
    """BU-style right-column comment box with underlined heading."""
    body = comment_rows(item, extra_rows)
    return (
        f"<aside class='note'><h5>{_esc(heading)}</h5><table>{body}</table>"
        f"<details class='comment'><summary>Nachweis einklappen</summary></details></aside>"
    )


def change_row(flow_html: str, note_html: str | None) -> str:
    if note_html:
        return f"<div class='row'><div class='flow'>{flow_html}</div>{note_html}</div>"
    return f"<div class='row'><div class='flow'>{flow_html}</div><span></span></div>"


def render_change_block(change: dict, cls: str) -> str:
    old_text = ((change.get("old") or {}).get("text")) or ""
    new_text = ((change.get("new") or {}).get("text")) or ""
    ctype = change.get("change_type")
    cid = _esc(change.get("change_id"))
    pages = change.get("source_pages")
    extra = None
    if isinstance(pages, dict):
        extra = [("Seiten", f"alt {pages.get('old')} / neu {pages.get('new')}")]
    if ctype == "DELETED":
        flow = f"<p class='el'><del>{_esc(old_text)}</del><span class='cmark'>{cid}</span></p>"
        heading = "Gelöscht"
    elif ctype == "ADDED":
        flow = f"<p class='el'><ins>{_esc(new_text)}</ins><span class='cmark'>{cid}</span></p>"
        heading = "Neu eingefügt"
    else:
        inline = max(len(old_text), len(new_text)) <= MAX_INLINE_CHARS
        sep = " " if inline else "<br/>"
        flow = (
            f"<p class='el'><del>{_esc(old_text)}</del>{sep}<ins>{_esc(new_text)}</ins>"
            f"<span class='cmark'>{cid}</span></p>"
        )
        heading = "Geändert"
    return change_row(flow, note_box(change, heading, extra))


def render_reseg_block(pair_evidence: dict, texts: dict[str, str]) -> str:
    oid = (pair_evidence.get("old_element_ids") or ["?"])[0]
    nid = (pair_evidence.get("new_element_ids") or ["?"])[0]
    fake = {
        "change_id": pair_evidence.get("candidate_id") or "RESEG",
        "change_type": "RESEGMENTATION_REVIEW",
        "needs_review": True,
        "review_reasons": pair_evidence.get("review_reasons") or [],
        "resolution": {"status": "resegmentation_suspect"},
        "similarity": pair_evidence.get("similarity"),
    }
    flow = (
        f"<p class='el'><del>{_esc(texts.get(oid, ''))}</del><br/><ins>{_esc(texts.get(nid, ''))}</ins>"
        f"<span class='cmark'>{_esc(fake['change_id'])}</span></p>"
    )
    return change_row(flow, note_box(fake, "Segmentierungshinweis"))


def render_table_change(record: dict) -> str:
    classification = record.get("classification") or record.get("change_type")
    old_t, new_t = record.get("old") or {}, record.get("new") or {}
    head = (
        f"<h4>{_esc(record.get('table_change_id'))} &middot; {_esc(classification)} &middot; "
        f"old pages {(old_t.get('pages') or [])} &rarr; new pages {(new_t.get('pages') or [])}</h4>"
    )
    lines = []
    shown = 0
    for cell in record.get("cell_changes") or []:
        cls = cell.get("classification")
        if cls == "UNCHANGED":
            continue
        ot = ((cell.get("old") or {}).get("text")) or ""
        nt = ((cell.get("new") or {}).get("text")) or ""
        ref = f"[r{_short(cell.get('old_row_index'), 4)}/c{_short(cell.get('column_index'), 3)}]"
        if cls == "ADDED":
            lines.append(f"<div class='cellrow'>{ref} <ins>+ {_short(nt, 160)}</ins></div>")
        elif cls == "DELETED":
            lines.append(f"<div class='cellrow'>{ref} <del>- {_short(ot, 160)}</del></div>")
        else:
            lines.append(
                f"<div class='cellrow'>{ref} <del>{_short(ot, 140)}</del> "
                f"<ins>{_short(nt, 140)}</ins> <span style='color:#888'>({_esc(cls)})</span></div>"
            )
        shown += 1
        if shown >= 80:
            lines.append("<div class='cellrow'>... further cells omitted</div>")
            break
    if not lines:
        lines.append("<div class='cellrow'>(structure/layout-only differences - see index)</div>")
    fake = {
        "change_id": record.get("table_change_id"),
        "change_type": record.get("change_type"),
        "needs_review": record.get("needs_review"),
        "review_reasons": record.get("review_reasons") or [],
        "resolution": record.get("resolution") or {},
    }
    extra = [
        ("Tabellen", f"alt={','.join(old_t.get('table_ids') or []) or '-'} "
                     f"neu={','.join(new_t.get('table_ids') or []) or '-'}"),
        ("Form", f"alt {old_t.get('rows')}x{old_t.get('columns')} / "
                 f"neu {new_t.get('rows')}x{new_t.get('columns')}"),
    ]
    return f"<div class='tableblock'>{head}{''.join(lines)}{note_box(fake, 'Tabellenänderung', extra)}</div>"


def render(root: Path) -> Path:
    comparison, old_doc, new_doc = load_outputs(root)
    out_dir = root / "output"

    elements = sorted(
        (old_doc.get("document") or {}).get("elements") or [],
        key=lambda e: e.get("reading_order") if isinstance(e.get("reading_order"), int) else 10**12,
    )
    elements_by_id = {e.get("element_id"): e for e in elements}

    del_mod_by_old: dict[str, dict] = {}
    added_by_new: dict[str, dict] = {}
    for change in comparison.get("changes") or []:
        if change.get("change_type") == "ADDED":
            added_by_new[(change.get("new") or {}).get("element_id")] = change
        else:
            del_mod_by_old[(change.get("old") or {}).get("element_id")] = change

    reseg_pairs: list[dict] = []
    texts: dict[str, str] = {}
    new_elements = (new_doc.get("document") or {}).get("elements") or []
    new_by_id = {e.get("element_id"): e for e in new_elements}
    for item in comparison.get("review_queue") or []:
        if item.get("source_kind") != "resegmentation_pair":
            continue
        ev = item.get("evidence") or {}
        reseg_pairs.append(ev)
        for eid in ev.get("old_element_ids") or []:
            el = elements_by_id.get(eid)
            if el:
                texts[eid] = el.get("text") or ""
        for eid in ev.get("new_element_ids") or []:
            el = new_by_id.get(eid)
            if el:
                texts[eid] = el.get("text") or ""

    added_anchor_ro = resolve_added_anchors(
        comparison,
        out_dir / "comparison_candidates_with_movement.json",
        out_dir / "exact_element_matches.json",
    )
    pending_adds: dict[int, list[dict]] = {}
    for elem_id, change in added_by_new.items():
        pending_adds.setdefault(added_anchor_ro.get(elem_id, -1), []).append(change)
    emitted_added: set[str] = set()

    story = ["<main>",
             "<h2 style='font-size:16px;color:#555'>Inline-Redline &ndash; alte Fassung mit &Auml;nderungsmarkierungen</h2>",
             "<p style='font-size:12px;color:#777'>"
             "<span style='color:#c00000;text-decoration:line-through'>durchgestrichen</span> = entfernt &middot; "
             "<span style='color:#c00000;text-decoration:underline'>unterstrichen</span> = neuer Text &middot; "
             "Rechte Spalte: Anmerkung/Nachweis je &Auml;nderung (ID, Status, &Auml;hnlichkeit, Gr&uuml;nde). "
             "Blaue Rahmen = Verdacht auf reine Segmentierungs&auml;nderung.</p>"]
    current_bucket = None
    for order, element in enumerate(elements):
        label = None
        text = (element.get("text") or "").strip()
        if (
            element.get("element_type") in {"heading", "title"}
            and 0 < len(text) <= 120
            and text.startswith(STRUCTURE_PREFIXES)
        ):
            label = text[:80]
        if label and label != current_bucket:
            current_bucket = label
            story.append(f"<div class='bucket'>{_esc(label)}</div>")

        elem_id = element.get("element_id")

        for change in pending_adds.get(order - 1, []):
            nid = (change.get("new") or {}).get("element_id")
            emitted_added.add(nid)
            story.append(render_change_block(change, ""))

        if elem_id in del_mod_by_old:
            change = del_mod_by_old[elem_id]
            story.append(render_change_block(change, ""))
            continue

        reseg_here = next(
            (ev for ev in reseg_pairs if (ev.get("old_element_ids") or [None])[0] == elem_id),
            None,
        )
        if reseg_here is not None:
            story.append(render_reseg_block(reseg_here, texts))
            continue

        etype = element.get("element_type")
        if etype in {"header", "footer", "page_number"}:
            continue
        if etype == "table":
            story.append(
                f"<p class='el' style='color:#999'>[{_esc(elem_id)} - unver&auml;nderte Tabelle]</p>"
            )
            continue
        if not text:
            continue
        css_class = "el heading" if etype in {"heading", "title"} else "el solo"
        story.append(f"<p class='{css_class}'>{_esc(text)}</p>")

    for elem_id, change in sorted(
        added_by_new.items(),
        key=lambda kv: (kv[1].get("new") or {}).get("reading_order") or 0,
    ):
        if elem_id in emitted_added:
            continue
        story.append(render_change_block(change, ""))

    table_changes = comparison.get("table_changes") or []
    if table_changes:
        story.append("<div class='bucket'>Tabellen&auml;nderungen</div>")
        for record in table_changes:
            story.append(render_table_change(record))

    story.append("</main>")
    stats = comparison.get("statistics") or {}
    header_counts = ", ".join(f"{k}: {v}" for k, v in (stats.get("change_type_counts") or {}).items())
    html_doc = (
        "<!doctype html><html lang='de'><head><meta charset='utf-8'/>"
        "<title>CRR Comparison Redline</title><style>" + _CSS + "</style></head><body>"
        "<header class='bar'><h1>CRR Vergleich - Phase 1 Redline Review</h1>"
        f"<p>{_esc(header_counts)} &middot; review queue: {stats.get('review_queue', '?')}</p></header>"
        + "".join(story)
        + "<footer class='note'>Generated by crr_compare - deterministic Phase-1 pipeline "
        "(LLM evaluation optional/disabled)</footer></body></html>"
    )

    target = out_dir / "bu_comparison_redline.html"
    target.write_text(html_doc, encoding="utf-8")
    print(f"Saved redline: {target}")
    print(f"Redline size: {target.stat().st_size / 1024:.0f} KB")
    return target


if __name__ == "__main__":
    render(find_project_root())
