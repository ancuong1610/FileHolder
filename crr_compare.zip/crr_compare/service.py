"""Comparison job service (FastAPI).

Run:
    .venv/bin/uvicorn crr_compare.service:app --port 8321

Endpoints:
  POST /jobs            upload old+new (PDFs or DI-chunk JSONs) -> job id
  GET  /jobs/{id}       status + stage progress + statistics when done
  GET  /jobs/{id}/artifacts            artifact list + relative paths
  GET  /jobs/{id}/artifacts/{name}     download an artifact (redline html, index, ...)
  GET  /jobs/{id}/changes              canonical changes, optional filters
  GET  /jobs/{id}/review-queue.csv    BU triage export

Jobs run in a background thread via `python -m crr_compare run` inside an
isolated job workspace (workspace/jobs/<id>/), so a job can never corrupt
the interactive workspace.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
import threading
import uuid
from pathlib import Path

from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.responses import FileResponse, PlainTextResponse, Response

from crr_compare.common import REPO_ROOT

app = FastAPI(title="Regulatory Document Comparison API", version="0.1.0")

JOBS_ROOT = REPO_ROOT / "workspace" / "jobs"
JOBS_ROOT.mkdir(parents=True, exist_ok=True)

ARTIFACT_NAMES = {
    "comparison_result.json",
    "phase2_change_index.json",
    "bu_comparison_redline.html",
    "review_queue_export.csv",
    "table_comparison_result.json",
    "llm_review_decisions.json",
}

STAGE_ORDER = [f"{i:02d}" for i in range(1, 16)]

_jobs_lock = threading.Lock()
_jobs: dict[str, dict] = {}


def _job_dir(job_id: str) -> Path:
    return JOBS_ROOT / job_id


def _read_job(job_id: str) -> dict:
    with _jobs_lock:
        if job_id in _jobs:
            return _jobs[job_id]
    status_path = _job_dir(job_id) / "job_status.json"
    if status_path.exists():
        return json.loads(status_path.read_text(encoding="utf-8"))
    raise HTTPException(404, f"Unknown job {job_id}")


def _persist(job_id: str, status: dict) -> None:
    (_job_dir(job_id) / "job_status.json").write_text(
        json.dumps(status, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    with _jobs_lock:
        _jobs[job_id] = status


def _run_pipeline(job_id: str) -> None:
    root = _job_dir(job_id)
    status = _read_job(job_id)
    status["state"] = "running"
    _persist(job_id, status)

    process = subprocess.run(
        [sys.executable, "-m", "crr_compare", "run", "--root", str(root)],
        cwd=str(REPO_ROOT),
        capture_output=True,
        text=True,
    )
    status = _read_job(job_id)
    status["returncode"] = process.returncode
    if process.returncode == 0:
        status["stages_completed"] = re.findall(r"--- stage (\d{2}) finished", process.stdout)
        status["state"] = "done"
    else:
        status["state"] = "failed"
        status["stderr_tail"] = process.stderr[-4000:]
    _persist(job_id, status)


def _store_upload(target: Path, upload: UploadFile) -> None:
    with target.open("wb") as handle:
        shutil.copyfileobj(upload.file, handle)


@app.post("/jobs")
async def create_job(old_file: UploadFile = File(...), new_file: UploadFile = File(...)) -> dict:
    """Create a comparison job. Accepts the two document extractions as PDFs
    (requires DI credentials in .env) or as pre-extracted DI chunk JSON."""
    job_id = uuid.uuid4().hex[:12]
    root = _job_dir(job_id)
    old_chunk_dir = root / "cache" / "di_chunks" / "old_crr_2024_01_09"
    new_chunk_dir = root / "cache" / "di_chunks" / "new_crr_2024_07_09"
    old_chunk_dir.mkdir(parents=True)
    new_chunk_dir.mkdir(parents=True)
    (root / "output").mkdir()

    _store_upload(old_chunk_dir / "chunk_001_pages_0001_0100.json", old_file)
    _store_upload(new_chunk_dir / "chunk_001_pages_0001_0100.json", new_file)

    # Validate both are JSON with a pages array before accepting the job.
    for path in (old_chunk_dir / "chunk_001_pages_0001_0100.json",
                 new_chunk_dir / "chunk_001_pages_0001_0100.json"):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            assert isinstance(payload.get("pages"), list)
        except Exception as exc:
            shutil.rmtree(root, ignore_errors=True)
            raise HTTPException(400, f"Upload is not a DI extraction JSON ({path.name}): {exc}")

    status = {"job_id": job_id, "state": "queued", "stages_completed": []}
    _persist(job_id, status)
    threading.Thread(target=_run_pipeline, args=(job_id,), daemon=True).start()
    return status


@app.get("/jobs/{job_id}")
def job_status(job_id: str) -> dict:
    return _read_job(job_id)


@app.get("/jobs/{job_id}/artifacts")
def list_artifacts(job_id: str) -> dict:
    _read_job(job_id)
    out = _job_dir(job_id) / "output"
    files = sorted(p.name for p in out.iterdir() if p.is_file()) if out.exists() else []
    return {"job_id": job_id, "artifacts": files}


@app.get("/jobs/{job_id}/artifacts/{name}")
def get_artifact(job_id: str, name: str):
    if name not in ARTIFACT_NAMES:
        raise HTTPException(404, f"Unknown artifact {name}")
    path = _job_dir(job_id) / "output" / name
    if not path.exists():
        raise HTTPException(404, f"Artifact not produced (yet): {name}")
    media = "text/html" if name.endswith(".html") else (
        "text/csv" if name.endswith(".csv") else "application/json"
    )
    if name.endswith(".csv"):
        return PlainTextResponse(path.read_text(encoding="utf-8-sig"), media_type=media)
    return FileResponse(path, media_type=media, filename=name)


@app.get("/jobs/{job_id}/changes")
def get_changes(job_id: str, change_type: str | None = None, needs_review: bool | None = None) -> Response:
    canonical_path = _job_dir(job_id) / "output" / "comparison_result.json"
    if not canonical_path.exists():
        raise HTTPException(404, "Job not finished or failed")
    canonical = json.loads(canonical_path.read_text(encoding="utf-8"))
    changes = canonical.get("changes") or []
    if change_type:
        changes = [c for c in changes if c.get("change_type") == change_type.upper()]
    if needs_review is not None:
        changes = [
            c for c in changes
            if bool((c.get("resolution") or {}).get("needs_review")) == needs_review
        ]
    return Response(
        json.dumps({"count": len(changes), "changes": changes}, ensure_ascii=False),
        media_type="application/json",
    )


@app.get("/jobs/{job_id}/review-queue.csv")
def review_queue_csv(job_id: str):
    return get_artifact(job_id, "review_queue_export.csv")
