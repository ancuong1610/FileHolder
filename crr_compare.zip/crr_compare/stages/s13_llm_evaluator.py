"""Stage 13 - optional bounded LLM evaluator (mock / real / disabled).

Modes via env CRR_RUN_LLM:
  false  - every packet becomes UNCERTAIN / not_run (fully deterministic)
  mock   - deterministic rule-based evaluator; writes a request/response
           trace per packet to output/llm_review_responses.jsonl so the
           real API shape can be inspected without any network call
  real   - actual provider call (bbk_ai_hub or openai_compatible)

The mock reads each packet, decides among the four bounded verdicts, and
emits the same strict-JSON response contract the real API must produce;
parsing/validation/fallback flow through the identical code path.
"""
import hashlib
import json
import os
import re
import time
from collections import Counter
from pathlib import Path
from typing import Any

from crr_compare.common import find_project_root, output_dir

STEP13_VERSION = "2.1.0-mock-capable-llm"
ALLOWED = {"KEEP_CHANGE", "SUPPRESS_ARTIFACT", "STRUCTURAL_ONLY", "UNCERTAIN"}

MODE = os.getenv("CRR_RUN_LLM", "mock").strip().lower()
RUN_LLM = MODE not in {"false", "0", "no", "off"}
LLM_PROVIDER = os.getenv("LLM_PROVIDER", "bbk_ai_hub")
LLM_MODEL = os.getenv("LLM_MODEL", "mock-evaluator-v1" if MODE == "mock" else "")

PROJECT_ROOT = find_project_root()
OUTPUT_DIR = output_dir(PROJECT_ROOT)
PACKETS_PATH = OUTPUT_DIR / "llm_review_packets.json"
DECISIONS_PATH = OUTPUT_DIR / "llm_review_decisions.json"
TRACE_PATH = OUTPUT_DIR / "llm_review_responses.jsonl"

packets_doc = json.loads(PACKETS_PATH.read_text(encoding="utf-8"))
if packets_doc.get("comparison_stage") != "special_case_packet_generation":
    raise SystemExit("Stage 13 requires Step 12 packets.")
packets = packets_doc.get("packets") or []
print(f"Packets: {len(packets)} | CRR_RUN_LLM = {MODE}")

SYSTEM_MESSAGE = """You are a conservative evaluator inside a regulatory-document comparison pipeline.
You do NOT re-match documents and you do NOT invent missing source content.

Choose exactly one decision:
KEEP_CHANGE: evidence supports a real source/content change.
SUPPRESS_ARTIFACT: difference is only extraction/layout/segmentation noise.
STRUCTURAL_ONLY: difference is structural/segmentation-only and should not be presented as a substantive textual change.
UNCERTAIN: evidence is insufficient.

Return strict JSON:
{
  "decision": "...",
  "confidence": 0.0,
  "reason": "...",
  "evidence_refs": ["old.element_id", "new.element_id"]
}

Be conservative. If unsure, return UNCERTAIN.
"""


def build_prompt(packet: dict[str, Any]) -> str:
    return (
        "Evaluate this bounded special case.\n\n"
        + json.dumps(packet, ensure_ascii=False, indent=2)
    )


# --------------------------------------------------------------------------
# Mock evaluator
# --------------------------------------------------------------------------

def _packet_tokens_join(packet: dict[str, Any]) -> tuple[str, str] | None:
    diff = ((packet.get("payload") or {}).get("token_diff") or {}).get(
        "comparison_token_diff"
    ) or {}
    changes = diff.get("changes") or []
    if not changes:
        return None
    old_join = "".join(t for c in changes for t in (c.get("old_tokens") or [])).casefold()
    new_join = "".join(t for c in changes for t in (c.get("new_tokens") or [])).casefold()
    return old_join, new_join


def _payload_similarity(packet: dict[str, Any]) -> float | None:
    payload = packet.get("payload") or {}
    for key in ("similarity",):
        value = payload.get(key)
        if isinstance(value, (int, float)):
            return float(value)
    evidence = payload.get("matching_evidence") or {}
    value = evidence.get("combined_similarity")
    return float(value) if isinstance(value, (int, float)) else None


def mock_decide(packet: dict[str, Any]) -> tuple[str, float, str]:
    """Deterministic rule-based verdict for one packet."""
    case_type = str(packet.get("case_type") or "")
    similarity = _payload_similarity(packet)

    if case_type in {"possible_extraction_word_split", "hyphenation_wrap_artifact",
                     "tokenization_neutral_difference", "table_extraction_artifact"}:
        return "SUPPRESS_ARTIFACT", 0.9, "Token content identical; difference is extraction/layout artifact only."
    if case_type in {"possible_marker_or_version_marker_difference", "structural_heading_boundary",
                     "structural_boundary", "resegmentation_suspect"}:
        return "STRUCTURAL_ONLY", 0.85, "Difference is marker/segmentation/structural, not substantive text."
    if case_type == "ambiguous_modified_pair":
        if (similarity or 0.0) >= 0.9:
            return "KEEP_CHANGE", 0.8, f"High similarity pair ({similarity:.3f}) with a real token difference."
        return "UNCERTAIN", 0.3, "Ambiguous modified pair below high-confidence similarity."
    if case_type == "modified_with_review_evidence":
        if (similarity or 0.0) >= 0.86:
            return "KEEP_CHANGE", 0.8, f"Substantive modification (similarity {similarity:.3f})."
        return "UNCERTAIN", 0.3, "Review evidence without strong similarity."
    if case_type == "table_modified_with_review_evidence":
        if (similarity or 0.0) >= 0.8:
            return "KEEP_CHANGE", 0.8, f"Table content changed (combined similarity {similarity:.3f})."
        return "UNCERTAIN", 0.3, "Table change near similarity threshold."
    if case_type in {"deleted_table_candidate", "added_table_candidate"}:
        return "KEEP_CHANGE", 0.85, "One-sided table candidate: no counterpart exists on the other side."
    if case_type.endswith("_candidate_with_review_evidence"):
        return "UNCERTAIN", 0.3, "One-sided candidate carries review evidence; insufficient for auto-decision."
    return "UNCERTAIN", 0.3, "No rule matched; conservative default."


def call_llm_mock(packet: dict[str, Any]) -> str:
    prompt = build_prompt(packet)
    decision, confidence, reason = mock_decide(packet)
    old_el = ((packet.get("payload") or {}).get("old") or {})
    new_el = ((packet.get("payload") or {}).get("new") or {})
    raw = json.dumps(
        {
            "decision": decision,
            "confidence": confidence,
            "reason": reason,
            "evidence_refs": [
                ref for ref in (old_el.get("element_id"), new_el.get("element_id")) if ref
            ],
        },
        ensure_ascii=False,
    )
    trace = {
        "packet_id": packet.get("packet_id"),
        "route_id": packet.get("route_id"),
        "case_type": packet.get("case_type"),
        "request": {
            "model": LLM_MODEL,
            "system_chars": len(SYSTEM_MESSAGE),
            "prompt_chars": len(prompt),
            "prompt_sha256": hashlib.sha256(prompt.encode("utf-8")).hexdigest(),
        },
        "response": {
            "content": json.loads(raw),
            "simulated_latency_ms": 40 + (hash(packet.get("packet_id") or "") % 120),
        },
        "evaluator": "mock",
    }
    with TRACE_PATH.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(trace, ensure_ascii=False) + "\n")
    return raw


# --------------------------------------------------------------------------
# Real providers (unchanged behaviour)
# --------------------------------------------------------------------------

def response_text(value: Any) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        for key in ("text", "content", "response", "output_text", "answer"):
            if isinstance(value.get(key), str):
                return value[key]
    return str(value)


def call_llm_real(packet: dict[str, Any]) -> str:
    prompt = build_prompt(packet)
    if LLM_PROVIDER == "bbk_ai_hub":
        import bbk_ai_hub_sdk

        api_key = os.getenv("TIA_API_KEY") or os.getenv("BBK_AI_HUB_API_KEY")
        if not api_key:
            raise RuntimeError("Missing TIA_API_KEY / BBK_AI_HUB_API_KEY.")
        return response_text(bbk_ai_hub_sdk.invoke_text_api(api_key, prompt, SYSTEM_MESSAGE))
    if LLM_PROVIDER == "openai_compatible":
        from openai import OpenAI

        client = OpenAI(
            api_key=os.getenv("OPENAI_API_KEY"),
            base_url=os.getenv("OPENAI_BASE_URL") or None,
        )
        response = client.chat.completions.create(
            model=LLM_MODEL,
            messages=[
                {"role": "system", "content": SYSTEM_MESSAGE},
                {"role": "user", "content": prompt},
            ],
            temperature=0,
        )
        return response.choices[0].message.content or ""
    raise ValueError(f"Unsupported LLM_PROVIDER={LLM_PROVIDER!r}")


def call_llm(packet: dict[str, Any]) -> str:
    if MODE == "mock":
        return call_llm_mock(packet)
    return call_llm_real(packet)


def parse_decision(raw: str) -> dict[str, Any]:
    match = re.search(r"\{.*\}", raw, flags=re.S)
    if not match:
        raise ValueError("No JSON object found.")
    obj = json.loads(match.group(0))
    decision = obj.get("decision")
    if decision not in ALLOWED:
        raise ValueError(f"Invalid decision {decision!r}")
    confidence = float(obj.get("confidence", 0.0))
    if not 0.0 <= confidence <= 1.0:
        raise ValueError("confidence outside [0,1]")
    return {
        "decision": decision,
        "confidence": confidence,
        "reason": str(obj.get("reason") or ""),
        "evidence_refs": list(obj.get("evidence_refs") or []),
    }


# --------------------------------------------------------------------------
# Main loop
# --------------------------------------------------------------------------

decisions = []
if TRACE_PATH.exists():
    TRACE_PATH.unlink()

for packet in packets:
    base = {
        "packet_id": packet["packet_id"],
        "route_id": packet["route_id"],
        "candidate_id": packet.get("candidate_id"),
        "input_hash": packet["input_hash"],
        "case_type": packet.get("case_type"),
    }

    if not RUN_LLM:
        decisions.append({
            **base,
            "decision": "UNCERTAIN",
            "confidence": 0.0,
            "reason": "LLM evaluation disabled; review status preserved.",
            "evidence_refs": [],
            "evaluator": "not_run",
        })
        continue

    try:
        raw = call_llm(packet)
        parsed = parse_decision(raw)
        item = {**base, **parsed, "evaluator": LLM_MODEL if MODE == "mock" else LLM_PROVIDER}
    except Exception as exc:  # fallback keeps the pipeline conservative
        item = {
            **base,
            "decision": "UNCERTAIN",
            "confidence": 0.0,
            "reason": f"Evaluator failure: {type(exc).__name__}: {exc}",
            "evidence_refs": [],
            "evaluator": "fallback",
        }

    decisions.append(item)

result = {
    "schema_version": "1.1.0",
    "comparison_stage": "optional_llm_special_case_evaluation",
    "processing": {
        "version": STEP13_VERSION,
        "mode": MODE,
        "provider": (LLM_MODEL if MODE == "mock" else LLM_PROVIDER) if RUN_LLM else None,
        "trace_file": TRACE_PATH.name if RUN_LLM and MODE == "mock" else None,
    },
    "statistics": {
        "packets": len(packets),
        "decision_counts": dict(Counter(x["decision"] for x in decisions)),
    },
    "decisions": decisions,
}

DECISIONS_PATH.write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8",
)
print(json.dumps(result["statistics"], ensure_ascii=False, indent=2))
if MODE == "mock" and RUN_LLM:
    print(f"Request/response trace: {TRACE_PATH}")
print("Saved:", DECISIONS_PATH)
