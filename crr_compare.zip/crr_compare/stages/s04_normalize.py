"""Auto-converted from 04_normalize_content_v1_5_final_preprocess.ipynb (code cells only)."""
from crr_compare.common import find_project_root, get_page_number, set_page_number

# ---- cell 2 ----

import copy
import json
import re
import unicodedata
from pathlib import Path
from typing import Any

# ---- cell 4 ----
PROJECT_ROOT = find_project_root()
OUTPUT_DIR = PROJECT_ROOT / "output"

DOCUMENTS = {
    "old": {
        "input": OUTPUT_DIR / "old_document.json",
        "output": OUTPUT_DIR / "old_document_normalized.json",
    },
    "new": {
        "input": OUTPUT_DIR / "new_document.json",
        "output": OUTPUT_DIR / "new_document_normalized.json",
    },
}

for label, paths in DOCUMENTS.items():
    if not paths["input"].exists():
        raise FileNotFoundError(
            f"Missing {paths['input']}. Run the verified Step-3 notebook first."
        )

print(f"Project root: {PROJECT_ROOT}")
for label, paths in DOCUMENTS.items():
    print(f"{label}: {paths['input']}")

# ---- cell 6 ----
def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def save_json(data: dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)
    temporary.replace(path)


def get_document(model: dict[str, Any]) -> dict[str, Any]:
    document = model.get("document")
    if not isinstance(document, dict):
        raise ValueError("Incompatible input: expected model['document'] from Step 3.")
    elements = document.get("elements")
    if not isinstance(elements, list) or not elements:
        raise ValueError(
            "Incompatible or empty input: expected non-empty "
            "model['document']['elements']."
        )
    return document


source_models = {
    label: load_json(paths["input"])
    for label, paths in DOCUMENTS.items()
}

for label, model in source_models.items():
    document = get_document(model)
    print(f"{label}: loaded {len(document['elements']):,} Step-3 elements")

# ---- cell 8 ----
NORMALIZATION_VERSION = "1.5"

QUOTE_TRANSLATION = str.maketrans({
    "\u2018": "'", "\u2019": "'", "\u201a": "'", "\u201b": "'", "\u2032": "'",
    "\u201c": '"', "\u201d": '"', "\u201e": '"', "\u201f": '"', "\u2033": '"',
    "\u00ab": '"', "\u00bb": '"',
})
DASH_TRANSLATION = str.maketrans({
    "\u2010": "-", "\u2011": "-", "\u2012": "-", "\u2013": "-",
    "\u2014": "-", "\u2212": "-",
})

LINE_BREAK_HYPHEN = re.compile(r"(?<=\w)-[ \t]*\n[ \t]*(?=\w)")

FLATTENED_LINE_BREAK_HYPHEN = re.compile(
    r"(?P<left>[A-Za-zÄÖÜäöüß]{2,})-[ \t]+(?P<right>[A-Za-zÄÖÜäöüß]{2,})"
)

# Very conservative DI split-word repair without a hyphen.
# Example observed in the DI output:
#   Hauptgeschäftstätigkei t -> Hauptgeschäftstätigkeit
#
# Guardrails:
# - left fragment must be long (>= 12 alphabetic characters)
# - right fragment must be exactly one lowercase alphabetic character
# This avoids common structures such as "Artikel a", "Absatz b", etc.
SINGLE_LETTER_SPLIT_WORD = re.compile(
    r"(?P<left>[A-Za-zÄÖÜäöüß]{12,})[ \t]+(?P<right>[a-zäöüß])(?=$|[\s,.;:!?()\[\]{}\"'])"
)

# Conservative leading-list marker normalization.
# Only element-initial markers are touched:
#   "5) text"     -> "(5) text"
#   "(5) ) text"  -> "(5) text"
#   "1. . text"   -> "1. text"
#
# We do NOT remove numbering because it can be semantically meaningful.
LEADING_PAREN_NUMBER = re.compile(
    r"^\s*\(?(?P<num>\d{1,4}[a-z]?)\)\s*"
)
DUPLICATE_LEADING_CLOSE_PAREN = re.compile(
    r"^(?P<prefix>\(\d{1,4}[a-z]?\))\s*\)+\s*"
)
DUPLICATE_LEADING_DOT = re.compile(
    r"^(?P<prefix>\d{1,4}[a-z]?\.)\s*\.+\s*"
)

WHITESPACE = re.compile(r"\s+")

# ponytail: suspended-compound guard — a line-wrap continuation is never a
# function word, but a suspended hyphen ("Risiko- und Zinsrisiken" /
# "risk- and exposure") is always followed by one. Bilingual DE+EN union
# from crr_compare.lang_profile; widen there if false joins ever appear.
from crr_compare.lang_profile import SUSPENDED_HYPHEN_STOPWORDS


def _join_flattened_hyphenation(match: re.Match[str]) -> str:
    left = match.group("left")
    right = match.group("right")

    # A right fragment that is a standalone function word indicates a
    # suspended compound hyphen ("Risiko- und ..."), not line-wrap
    # hyphenation. Never join those.
    if right.casefold() in SUSPENDED_HYPHEN_STOPWORDS:
        return match.group(0)

    continuation_is_lowercase = right[:1].islower()
    both_fragments_uppercase = left.isupper() and right.isupper()

    if continuation_is_lowercase or both_fragments_uppercase:
        return left + right

    return match.group(0)


def normalize_leading_list_marker(value: str) -> tuple[str, bool]:
    original = value

    # Collapse duplicated punctuation first.
    value = DUPLICATE_LEADING_CLOSE_PAREN.sub(
        lambda m: f"{m.group('prefix')} ",
        value,
    )
    value = DUPLICATE_LEADING_DOT.sub(
        lambda m: f"{m.group('prefix')} ",
        value,
    )

    # Canonicalize bare numeric close-paren markers to parenthesized form.
    # Example: "5) text" -> "(5) text"
    match = LEADING_PAREN_NUMBER.match(value)
    if match:
        marker = match.group("num")
        # Only rewrite if the source really has a close-paren style marker.
        source_prefix = value[:match.end()]
        if ")" in source_prefix:
            value = f"({marker}) " + value[match.end():]

    return value, value != original


def normalize_text_with_flags(text: str) -> tuple[str, list[str]]:
    flags: list[str] = []

    value = unicodedata.normalize("NFC", text)
    if value != text:
        flags.append("unicode_nfc_normalized")

    if "\u00ad" in value:
        value = value.replace("\u00ad", "")
        flags.append("soft_hyphen_removed")

    if "\u00a0" in value:
        value = value.replace("\u00a0", " ")
        flags.append("non_breaking_space_normalized")

    normalized_line_endings = value.replace("\r\n", "\n").replace("\r", "\n")
    if normalized_line_endings != value:
        flags.append("line_endings_normalized")
    value = normalized_line_endings

    translated = value.translate(QUOTE_TRANSLATION).translate(DASH_TRANSLATION)
    if translated != value:
        flags.append("quote_or_dash_variant_standardized")
    value = translated

    if LINE_BREAK_HYPHEN.search(value):
        value = LINE_BREAK_HYPHEN.sub("", value)
        flags.append("line_break_hyphenation_joined")

    flattened_join_count = 0

    # Run to a fixed point because one join can expose the next line-wrap
    # artifact, e.g. "BEGRIFFS- BESTIM- MUNGEN":
    # pass 1 -> "BEGRIFFSBESTIM- MUNGEN"
    # pass 2 -> "BEGRIFFSBESTIMMUNGEN"
    #
    # This makes normalization idempotent in a single call.
    while True:
        pass_join_count = 0

        def flattened_replacer(match: re.Match[str]) -> str:
            nonlocal pass_join_count
            replacement = _join_flattened_hyphenation(match)
            if replacement != match.group(0):
                pass_join_count += 1
            return replacement

        new_value = FLATTENED_LINE_BREAK_HYPHEN.sub(flattened_replacer, value)
        flattened_join_count += pass_join_count

        if new_value == value:
            break

        value = new_value

    if flattened_join_count:
        flags.append("flattened_line_break_hyphenation_joined")

    # Repair a narrow class of DI word splits that have no hyphen.
    # Run to a fixed point for idempotence because joining one single-letter
    # fragment can expose another eligible split in the same token sequence.
    single_letter_split_count = 0

    while True:
        pass_split_count = 0

        def single_letter_split_replacer(match: re.Match[str]) -> str:
            nonlocal pass_split_count
            pass_split_count += 1
            return match.group("left") + match.group("right")

        new_value = SINGLE_LETTER_SPLIT_WORD.sub(
            single_letter_split_replacer,
            value,
        )

        single_letter_split_count += pass_split_count

        if new_value == value:
            break

        value = new_value

    if single_letter_split_count:
        flags.append("single_letter_split_word_joined")

    value, leading_marker_changed = normalize_leading_list_marker(value)
    if leading_marker_changed:
        flags.append("leading_list_marker_standardized")

    collapsed = WHITESPACE.sub(" ", value)
    if collapsed != value:
        flags.append("whitespace_collapsed")
    value = collapsed.strip()

    return value, list(dict.fromkeys(flags))


def normalize_text(text: str) -> str:
    return normalize_text_with_flags(text)[0]


def normalize_document(source_model: dict[str, Any]) -> dict[str, Any]:
    result = copy.deepcopy(source_model)
    document = get_document(result)
    elements = document["elements"]

    normalized_cells = 0
    changed_elements = 0
    flattened_element_count = 0
    flattened_cell_count = 0
    single_letter_split_element_count = 0
    single_letter_split_cell_count = 0
    leading_list_marker_element_count = 0
    leading_list_marker_cell_count = 0

    for element in elements:
        original_text = element.get("text")
        if not isinstance(original_text, str):
            raise TypeError(f"Element {element.get('element_id')} has non-string text.")

        normalized_text, flags = normalize_text_with_flags(original_text)
        element["normalized_text"] = normalized_text
        element["normalization_flags"] = flags

        if normalized_text != original_text:
            changed_elements += 1
        if "flattened_line_break_hyphenation_joined" in flags:
            flattened_element_count += 1
        if "single_letter_split_word_joined" in flags:
            single_letter_split_element_count += 1
        if "leading_list_marker_standardized" in flags:
            leading_list_marker_element_count += 1

        table = element.get("table")
        if table is not None:
            if element.get("element_type") != "table" or not isinstance(table, dict):
                raise ValueError(
                    f"Element {element.get('element_id')} has an invalid table payload."
                )

            for cell in table.get("cells") or []:
                cell_text = cell.get("text")
                if not isinstance(cell_text, str):
                    raise TypeError(f"Table cell {cell.get('cell_id')} has non-string text.")

                normalized_cell_text, cell_flags = normalize_text_with_flags(cell_text)
                cell["normalized_text"] = normalized_cell_text
                cell["normalization_flags"] = cell_flags

                if "flattened_line_break_hyphenation_joined" in cell_flags:
                    flattened_cell_count += 1
                if "single_letter_split_word_joined" in cell_flags:
                    single_letter_split_cell_count += 1
                if "leading_list_marker_standardized" in cell_flags:
                    leading_list_marker_cell_count += 1

                normalized_cells += 1

    processing = result.setdefault("processing", {})
    processing["normalization"] = {
        "version": NORMALIZATION_VERSION,
        "unicode_form": "NFC",
        "soft_hyphens_removed": True,
        "line_break_hyphenation_joined": True,
        "flattened_line_break_hyphenation_joined": True,
        "single_letter_split_word_joined": True,
        "flattened_hyphenation_policy": (
            "join alphabetic fragments with left fragment length >= 2 when "
            "the continuation begins lowercase or both fragments are uppercase; "
            "repeat until stable"
        ),
        "single_letter_split_word_policy": (
            "join only long alphabetic fragments (>=12 chars) followed by one "
            "lowercase alphabetic character; repeat until stable"
        ),
        "normalization_flags_recorded": True,
        "quote_variants_standardized": True,
        "dash_variants_standardized": True,
        "leading_list_marker_standardized": True,
        "whitespace_collapsed": True,
        "case_changed": False,
        "numbers_changed": False,
        "punctuation_removed": False,
    }

    statistics = document.setdefault("statistics", {})
    statistics["normalized_elements"] = len(elements)
    statistics["normalized_table_cells"] = normalized_cells
    statistics["elements_changed_by_normalization"] = changed_elements
    statistics["elements_with_flattened_hyphen_join"] = flattened_element_count
    statistics["table_cells_with_flattened_hyphen_join"] = flattened_cell_count
    statistics["elements_with_single_letter_split_join"] = single_letter_split_element_count
    statistics["table_cells_with_single_letter_split_join"] = single_letter_split_cell_count
    statistics["elements_with_leading_list_marker_standardization"] = leading_list_marker_element_count
    statistics["table_cells_with_leading_list_marker_standardization"] = leading_list_marker_cell_count

    return result


normalized_models = {
    label: normalize_document(model)
    for label, model in source_models.items()
}

for label, model in normalized_models.items():
    stats = model["document"]["statistics"]
    print(
        f"{label}: normalized {stats['normalized_elements']:,} elements and "
        f"{stats['normalized_table_cells']:,} table cells"
    )
    print(f"  changed elements: {stats['elements_changed_by_normalization']:,}")
    print(
        f"  flattened hyphen joins: "
        f"{stats['elements_with_flattened_hyphen_join']:,} elements, "
        f"{stats['table_cells_with_flattened_hyphen_join']:,} table cells"
    )
    print(
        f"  single-letter split joins: "
        f"{stats['elements_with_single_letter_split_join']:,} elements, "
        f"{stats['table_cells_with_single_letter_split_join']:,} table cells"
    )

# ---- cell 10 ----
def show_changes(model: dict[str, Any], limit: int = 25) -> None:
    elements = get_document(model)["elements"]
    changed = [
        element for element in elements
        if element["text"] != element["normalized_text"]
    ]

    print(f"Elements changed by normalization: {len(changed):,}")

    for element in changed[:limit]:
        print("=" * 90)
        print(
            f"{element['element_id']} type={element['element_type']} "
            f"page={element.get('primary_page')}"
        )
        print("FLAGS     :", element.get("normalization_flags", []))
        print("ORIGINAL  :", repr(element["text"][:500]))
        print("NORMALIZED:", repr(element["normalized_text"][:500]))

    if len(changed) > limit:
        print(f"... {len(changed) - limit:,} additional changes omitted")


def show_flattened_hyphenation_changes(
    model: dict[str, Any],
    limit: int = 50,
) -> None:
    elements = get_document(model)["elements"]

    affected = [
        element
        for element in elements
        if "flattened_line_break_hyphenation_joined"
        in element.get("normalization_flags", [])
    ]

    print(
        f"Elements with DI-flattened line-wrap hyphenation joined: "
        f"{len(affected):,}"
    )

    for element in affected[:limit]:
        print("-" * 90)
        print(
            f"{element['element_id']} type={element['element_type']} "
            f"page={element.get('primary_page')}"
        )
        print("ORIGINAL  :", repr(element["text"][:500]))
        print("NORMALIZED:", repr(element["normalized_text"][:500]))

    if len(affected) > limit:
        print(f"... {len(affected) - limit:,} additional cases omitted")



def show_single_letter_split_changes(
    model: dict[str, Any],
    limit: int = 50,
) -> None:
    elements = get_document(model)["elements"]

    affected = [
        element
        for element in elements
        if "single_letter_split_word_joined"
        in element.get("normalization_flags", [])
    ]

    print(
        f"Elements with conservative single-letter split repair: "
        f"{len(affected):,}"
    )

    for element in affected[:limit]:
        print("-" * 90)
        print(
            f"{element['element_id']} type={element['element_type']} "
            f"page={element.get('primary_page')}"
        )
        print("ORIGINAL  :", repr(element["text"][:500]))
        print("NORMALIZED:", repr(element["normalized_text"][:500]))

    if len(affected) > limit:
        print(f"... {len(affected) - limit:,} additional cases omitted")

for label, model in normalized_models.items():
    print(f"\n{label.upper()} — ALL NORMALIZATION CHANGES")
    show_changes(model)

    print(f"\n{label.upper()} — FLATTENED HYPHENATION REVIEW")
    show_flattened_hyphenation_changes(model)

    print(f"\n{label.upper()} — SINGLE-LETTER SPLIT-WORD REVIEW")
    show_single_letter_split_changes(model)

# ---- cell 12 ----
def validate_normalized_model(
    source: dict[str, Any],
    normalized: dict[str, Any],
) -> None:
    source_document = get_document(source)
    normalized_document = get_document(normalized)
    source_elements = source_document["elements"]
    normalized_elements = normalized_document["elements"]

    assert len(source_elements) == len(normalized_elements) > 0
    assert source.get("schema_version") == normalized.get("schema_version")
    assert normalized["processing"]["normalization"]["version"] == NORMALIZATION_VERSION

    immutable_fields = (
        "element_id", "element_type", "text", "spans", "bounding_regions",
        "primary_page", "primary_polygon", "reading_order", "section_path",
        "structure_heading", "comparison_eligible", "exclusion_reasons",
        "extraction_validation", "represented_by_table_id",
    )

    normalized_cell_count = 0

    for before, after in zip(source_elements, normalized_elements):
        for field in immutable_fields:
            assert before.get(field) == after.get(field), (
                f"Step 4 changed {field} for {before.get('element_id')}"
            )

        assert isinstance(after.get("normalized_text"), str)
        assert isinstance(after.get("normalization_flags"), list)

        # Idempotence: running normalization again must not change normalized text.
        assert normalize_text(after["normalized_text"]) == after["normalized_text"]

        before_table = before.get("table")
        after_table = after.get("table")

        if before_table is None:
            assert after_table is None
            continue

        assert before_table.get("row_count") == after_table.get("row_count")
        assert before_table.get("column_count") == after_table.get("column_count")

        before_cells = before_table.get("cells") or []
        after_cells = after_table.get("cells") or []
        assert len(before_cells) == len(after_cells)

        for before_cell, after_cell in zip(before_cells, after_cells):
            assert before_cell.get("text") == after_cell.get("text")
            assert before_cell.get("spans") == after_cell.get("spans")
            assert before_cell.get("bounding_regions") == after_cell.get("bounding_regions")
            assert isinstance(after_cell.get("normalized_text"), str)
            assert isinstance(after_cell.get("normalization_flags"), list)
            assert normalize_text(after_cell["normalized_text"]) == after_cell["normalized_text"]
            normalized_cell_count += 1

    stats = normalized_document["statistics"]
    assert stats["normalized_elements"] == len(normalized_elements)
    assert stats["normalized_table_cells"] == normalized_cell_count
    assert [e["reading_order"] for e in normalized_elements] == list(range(len(normalized_elements)))

    print(
        f"Passed: {len(normalized_elements):,} elements and "
        f"{normalized_cell_count:,} table cells; raw evidence and Step-3 decisions unchanged."
    )


for label in DOCUMENTS:
    print(label.upper())
    validate_normalized_model(source_models[label], normalized_models[label])

# ---- cell 14 ----
for label, paths in DOCUMENTS.items():
    save_json(normalized_models[label], paths["output"])
    assert paths["output"].exists()
    print(f"Saved: {paths['output']}")
