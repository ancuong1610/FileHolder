"""Auto-converted from 14_build_final_comparison_result_v2.ipynb (code cells only)."""
from crr_compare.common import find_project_root, get_page_number, set_page_number

# ---- cell 1 ----
import json
from collections import Counter
from pathlib import Path
from typing import Any

STEP14_VERSION = "2.0.0-canonical-result"

# ---- cell 2 ----
PROJECT_ROOT = find_project_root()
OUTPUT_DIR = PROJECT_ROOT / "output"

STEP9_PATH = OUTPUT_DIR / "comparison_candidates_with_movement.json"
STEP10_PATH = OUTPUT_DIR / "table_comparison_result.json"
ROUTING_PATH = OUTPUT_DIR / "review_routing.json"
DECISIONS_PATH = OUTPUT_DIR / "llm_review_decisions.json"
FINAL_PATH = OUTPUT_DIR / "comparison_result.json"

def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))

movement = load(STEP9_PATH)
tables = load(STEP10_PATH)
routing = load(ROUTING_PATH)
decisions_doc = load(DECISIONS_PATH) if DECISIONS_PATH.exists() else {"decisions":[]}
decisions = {x["route_id"]:x for x in decisions_doc.get("decisions") or []}
routes = {
    x["candidate_id"]: x
    for x in (routing.get("non_table_routes") or []) + (routing.get("table_routes") or [])
    if x.get("candidate_id")
}

# ---- cell 3 ----
def compact_element(element: dict[str, Any] | None) -> dict[str, Any] | None:
    if not isinstance(element, dict):
        return None
    return {
        "element_id": element.get("element_id"),
        "element_type": element.get("element_type"),
        "text": element.get("text"),
        "normalized_text": element.get("normalized_text"),
        "comparison_text": element.get("comparison_text"),
        "primary_page": element.get("primary_page"),
        "reading_order": element.get("reading_order"),
        "provisional_anchor_context": element.get("provisional_anchor_context"),
    }

def resolution_for(candidate_id: str) -> dict[str, Any]:
    route = routes.get(candidate_id)
    if not route:
        return {
            "route": "UNROUTED",
            "case_type": "unrouted",
            "method": "deterministic",
            "status": "review",
            "needs_review": True,
        }

    decision = decisions.get(route["route_id"])
    if decision and decision.get("decision") != "UNCERTAIN":
        decision_name = decision["decision"]
        if decision_name == "KEEP_CHANGE":
            status, needs_review = "accepted", False
        elif decision_name == "SUPPRESS_ARTIFACT":
            status, needs_review = "suppressed_artifact", False
        elif decision_name == "STRUCTURAL_ONLY":
            status, needs_review = "structural_only", False
        else:
            status, needs_review = "review", True
        return {
            "route": route["route"],
            "case_type": route["case_type"],
            "method": "llm_assisted",
            "status": status,
            "needs_review": needs_review,
            "packet_decision": decision,
        }

    route_name = route["route"]
    if route_name == "ACCEPT_DETERMINISTIC":
        status, needs_review = "accepted", False
    elif route_name == "NON_SEMANTIC":
        status, needs_review = "non_semantic", False
    elif route_name == "SPECIAL_CASE_RULE":
        status, needs_review = "review", True
    else:
        status, needs_review = "review", True

    return {
        "route": route_name,
        "case_type": route["case_type"],
        "method": "deterministic",
        "status": status,
        "needs_review": needs_review,
        "review_reasons": route.get("review_reasons") or [],
    }

def change_type_for_group(group: str) -> str:
    return {
        "modified":"MODIFIED",
        "modified_review":"MODIFIED",
        "deleted":"DELETED",
        "added":"ADDED",
    }[group]

# ---- cell 4 ----
changes = []
review_queue = []
non_semantic_events = []

for group in ("modified","modified_review","deleted","added"):
    for item in movement.get(group) or []:
        cid = item["candidate_id"]
        resolution = resolution_for(cid)
        record = {
            "change_id": f"CHANGE-{len(changes)+1:06d}",
            "source_candidate_id": cid,
            "source_group": group,
            "change_type": change_type_for_group(group),
            "old": compact_element(item.get("old")),
            "new": compact_element(item.get("new")),
            "token_diff": item.get("token_diff"),
            "similarity": item.get("similarity"),
            "resolution": resolution,
            "provenance": {
                "step9_candidate_id": cid,
                "matching_not_recomputed": True,
            },
        }

        if resolution["status"] == "suppressed_artifact":
            non_semantic_events.append({**record, "event_type":"SUPPRESSED_ARTIFACT"})
            continue
        if resolution["status"] == "structural_only":
            non_semantic_events.append({**record, "event_type":"STRUCTURAL_ONLY"})
            continue

        changes.append(record)
        if resolution["needs_review"]:
            review_queue.append({
                "review_id": f"REVIEW-{len(review_queue)+1:06d}",
                "source_kind": "non_table_change",
                "change_id": record["change_id"],
                "source_candidate_id": cid,
                "case_type": resolution["case_type"],
                "resolution": resolution,
            })

# Duplicate exact assignment is never a substantive change.
for item in movement.get("duplicate_exact_review") or []:
    cid = item["candidate_id"]
    review_queue.append({
        "review_id": f"REVIEW-{len(review_queue)+1:06d}",
        "source_kind": "duplicate_exact_assignment",
        "source_candidate_id": cid,
        "case_type": "duplicate_exact_assignment",
        "resolution": resolution_for(cid),
    })

for item in movement.get("relocated") or []:
    non_semantic_events.append({
        "event_id": f"EVENT-{len(non_semantic_events)+1:06d}",
        "event_type": "RELOCATED_UNCHANGED",
        "source_candidate_id": item.get("candidate_id"),
        "old": compact_element(item.get("old")),
        "new": compact_element(item.get("new")),
    })

# Evidence-only review queues routed in Step 11 must reach the canonical
# result; previously they were silently dropped.
for source_kind, group_name, case_type in (
    ("movement_block", "movement_review", "movement_block_review"),
    ("structural_split_merge", "structural_split_merge_review", "structural_split_merge"),
    ("structural_boundary", "structural_boundary_review", "structural_boundary"),
):
    for item in movement.get(group_name) or []:
        evidence_id = item.get("candidate_id") or item.get("review_id")
        if not evidence_id:
            continue
        review_queue.append({
            "review_id": f"REVIEW-{len(review_queue)+1:06d}",
            "source_kind": source_kind,
            "source_evidence_id": evidence_id,
            "source_candidate_id": evidence_id,
            "case_type": case_type,
            "resolution": resolution_for(evidence_id),
            "evidence": item,
        })

# ---- cell 5 ----
table_changes = []
for match in tables.get("table_matches") or []:
    cid = match["table_match_id"]
    resolution = resolution_for(cid)
    cls = match.get("classification")

    if cls in {"UNCHANGED","LAYOUT_EQUIVALENT"}:
        continue

    record = {
        "table_change_id": f"TABLE-CHANGE-{len(table_changes)+1:05d}",
        "source_table_match_id": cid,
        "change_type": "TABLE_MODIFIED",
        "classification": cls,
        "old": match.get("old"),
        "new": match.get("new"),
        "cell_changes": match.get("cell_changes") or [],
        "resolution": resolution,
        "review_reasons": match.get("review_reasons") or [],
    }

    if resolution["status"] in {"suppressed_artifact","structural_only"}:
        non_semantic_events.append({**record, "event_type": resolution["status"].upper()})
        continue

    table_changes.append(record)
    if resolution["needs_review"]:
        review_queue.append({
            "review_id": f"REVIEW-{len(review_queue)+1:06d}",
            "source_kind": "table_change",
            "table_change_id": record["table_change_id"],
            "source_candidate_id": cid,
            "case_type": resolution["case_type"],
            "resolution": resolution,
        })

for group, ctype in (
    ("deleted_table_candidates","TABLE_DELETED"),
    ("added_table_candidates","TABLE_ADDED"),
):
    for table in tables.get(group) or []:
        cid = table["logical_table_id"]
        resolution = resolution_for(cid)
        record = {
            "table_change_id": f"TABLE-CHANGE-{len(table_changes)+1:05d}",
            "source_table_match_id": cid,
            "change_type": ctype,
            "old": table if group.startswith("deleted") else None,
            "new": table if group.startswith("added") else None,
            "cell_changes": [],
            "resolution": resolution,
        }
        table_changes.append(record)
        if resolution["needs_review"]:
            review_queue.append({
                "review_id": f"REVIEW-{len(review_queue)+1:06d}",
                "source_kind": "table_change",
                "table_change_id": record["table_change_id"],
                "source_candidate_id": cid,
                "case_type": resolution["case_type"],
                "resolution": resolution,
            })

for item in movement.get("resegmentation_review") or []:
    evidence_id = item.get("candidate_id")
    if not evidence_id:
        continue
    review_queue.append({
        "review_id": f"REVIEW-{len(review_queue)+1:06d}",
        "source_kind": "resegmentation_pair",
        "source_candidate_id": evidence_id,
        "case_type": "resegmentation_suspect",
        "resolution": resolution_for(evidence_id),
        "evidence": {
            "old_element_ids": [e["element_id"] for e in [item.get("old")] if isinstance(e, dict) and e.get("element_id")],
            "new_element_ids": [e["element_id"] for e in [item.get("new")] if isinstance(e, dict) and e.get("element_id")],
            "similarity": item.get("similarity"),
            "review_reasons": item.get("review_reasons") or [],
        },
    })

# Unresolved table groups (same-context residual tables) are HUMAN_REVIEW
# items; the underlying tables never become add/delete candidates, so they
# must be surfaced here or they vanish from the canonical result.
unresolved_table_reviews = []
for group in tables.get("unresolved_table_groups") or []:
    group_id = group.get("review_group_id")
    if not group_id:
        continue
    entry = {
        "review_id": f"REVIEW-{len(review_queue)+1:06d}",
        "source_kind": "unresolved_table_group",
        "source_candidate_id": group_id,
        "case_type": "unresolved_table_group",
        "resolution": resolution_for(group_id),
        "evidence": group,
    }
    review_queue.append(entry)
    unresolved_table_reviews.append(entry)

# ---- cell 6 ----
final = {
    "schema_version": "2.0.0",
    "comparison_stage": "phase_1_final_comparison",
    "old_document": movement.get("old_document"),
    "new_document": movement.get("new_document"),
    "processing": {
        "version": STEP14_VERSION,
        "canonical_backend_contract": True,
        "matching_recomputed": False,
        "llm_optional": True,
        "uncertainty_preserved": True,
    },
    "statistics": {
        "changes": len(changes),
        "table_changes": len(table_changes),
        "review_queue": len(review_queue),
        "non_semantic_events": len(non_semantic_events),
        "change_type_counts": dict(Counter(x["change_type"] for x in changes)),
        "resolution_status_counts": dict(Counter(x["resolution"]["status"] for x in changes)),
    },
    "changes": changes,
    "table_changes": table_changes,
    "review_queue": review_queue,
    "non_semantic_events": non_semantic_events,
    "unresolved_table_reviews": unresolved_table_reviews,
}

# Stable uniqueness.
assert len({x["change_id"] for x in changes}) == len(changes)
assert len({x["table_change_id"] for x in table_changes}) == len(table_changes)
assert all(
    x["resolution"]["status"] != "accepted" or not x["resolution"]["needs_review"]
    for x in changes
)

# Every Step-11 route that points at evidence this stage consumes must have
# been resolved; UNROUTED entries indicate a broken step 9/10/11 contract.
unrouted = [x for x in review_queue if (x.get("resolution") or {}).get("route") == "UNROUTED"]
print(f"Review queue: {len(review_queue)} entries ({len(unrouted)} unrouted)")

FINAL_PATH.write_text(
    json.dumps(final, ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8",
)
print(json.dumps(final["statistics"], ensure_ascii=False, indent=2))
print("Saved:", FINAL_PATH)
