"""Auto-converted from 12_build_special_case_packets_v2.ipynb (code cells only)."""
from crr_compare.common import find_project_root, get_page_number, set_page_number

# ---- cell 1 ----
import hashlib, json
from pathlib import Path
from typing import Any

STEP12_VERSION = "2.0.0-special-case-packets"
MAX_TEXT_CHARS = 6000

# ---- cell 2 ----
PROJECT_ROOT = find_project_root()
OUTPUT_DIR = PROJECT_ROOT / "output"
ROUTING_PATH = OUTPUT_DIR / "review_routing.json"
STEP9_PATH = OUTPUT_DIR / "comparison_candidates_with_movement.json"
STEP10_PATH = OUTPUT_DIR / "table_comparison_result.json"
PACKETS_PATH = OUTPUT_DIR / "llm_review_packets.json"

def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))

def save_json(value: dict[str, Any], path: Path) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)

routing = load_json(ROUTING_PATH)
movement = load_json(STEP9_PATH)
tables = load_json(STEP10_PATH)

if routing.get("comparison_stage") != "deterministic_review_routing":
    raise ValueError("Step 12 requires Step 11 routing output.")

# ---- cell 3 ----
def build_indexes():
    non_table = {}
    for group in ("modified","modified_review","duplicate_exact_review","relocated","deleted","added"):
        for item in movement.get(group) or []:
            cid = item.get("candidate_id")
            if cid:
                non_table[cid] = (group, item)

    structural = {}
    for group in ("movement_review","structural_split_merge_review","structural_boundary_review"):
        for item in movement.get(group) or []:
            key = item.get("candidate_id") or item.get("review_id")
            if key:
                structural[key] = (group, item)

    table_match = {
        x.get("table_match_id"): x
        for x in tables.get("table_matches") or []
        if x.get("table_match_id")
    }
    table_residual = {}
    for group in ("deleted_table_candidates","added_table_candidates"):
        for x in tables.get(group) or []:
            if x.get("logical_table_id"):
                table_residual[x["logical_table_id"]] = (group, x)
    table_review = {
        x.get("review_group_id"): x
        for x in tables.get("unresolved_table_groups") or []
        if x.get("review_group_id")
    }
    return non_table, structural, table_match, table_residual, table_review

NT, ST, TM, TR, TG = build_indexes()

def compact_element(element: dict[str, Any] | None) -> dict[str, Any] | None:
    if not isinstance(element, dict):
        return None
    return {
        "element_id": element.get("element_id"),
        "element_type": element.get("element_type"),
        "text": (element.get("text") or "")[:MAX_TEXT_CHARS],
        "normalized_text": (element.get("normalized_text") or "")[:MAX_TEXT_CHARS],
        "comparison_text": (element.get("comparison_text") or "")[:MAX_TEXT_CHARS],
        "primary_page": element.get("primary_page"),
        "reading_order": element.get("reading_order"),
        "provisional_anchor_context": element.get("provisional_anchor_context"),
        "extraction_validation": element.get("extraction_validation"),
    }

def payload_for_route(route: dict[str, Any]) -> dict[str, Any]:
    cid = route.get("candidate_id")
    source_kind = route.get("source_kind")

    if source_kind == "non_table":
        group, item = NT[cid]
        return {
            "source_group": group,
            "old": compact_element(item.get("old")),
            "new": compact_element(item.get("new")),
            "similarity": item.get("similarity"),
            "similarity_evidence": item.get("similarity_evidence"),
            "token_diff": item.get("token_diff"),
            "upstream_review_reasons": item.get("review_reasons") or [],
        }

    if source_kind == "structural_evidence":
        group, item = ST[cid]
        return {"source_group": group, "evidence": item}

    if source_kind == "table_match":
        item = TM[cid]
        changed_cells = [
            c for c in item.get("cell_changes") or []
            if c.get("classification") != "UNCHANGED"
        ]
        return {
            "source_group": "table_matches",
            "table_match_id": cid,
            "classification": item.get("classification"),
            "old": item.get("old"),
            "new": item.get("new"),
            "matching_evidence": item.get("matching_evidence"),
            "context_relation": item.get("context_relation"),
            "review_reasons": item.get("review_reasons") or [],
            "changed_cells": changed_cells[:80],
        }

    if source_kind == "table_residual":
        group, item = TR[cid]
        return {"source_group": group, "table": item}

    if source_kind == "table_review_group":
        return {"source_group": "unresolved_table_groups", "evidence": TG[cid]}

    raise KeyError(f"Unsupported route source_kind={source_kind!r}")

# ---- cell 4 ----
eligible = [
    item for item in
    (routing.get("non_table_routes") or []) + (routing.get("table_routes") or [])
    if item.get("route") == "SPECIAL_CASE_LLM_OPTIONAL"
]

packets = []
for route in eligible:
    payload = payload_for_route(route)
    packet_core = {
        "route_id": route["route_id"],
        "candidate_id": route.get("candidate_id"),
        "case_type": route.get("case_type"),
        "review_reasons": route.get("review_reasons") or [],
        "allowed_decisions": [
            "KEEP_CHANGE",
            "SUPPRESS_ARTIFACT",
            "STRUCTURAL_ONLY",
            "UNCERTAIN",
        ],
        "payload": payload,
    }
    raw = json.dumps(packet_core, ensure_ascii=False, sort_keys=True).encode("utf-8")
    input_hash = hashlib.sha256(raw).hexdigest()
    packets.append({
        "packet_id": f"CASE-{len(packets)+1:06d}",
        "input_hash": input_hash,
        **packet_core,
    })

result = {
    "schema_version": "1.0.0",
    "comparison_stage": "special_case_packet_generation",
    "processing": {
        "version": STEP12_VERSION,
        "llm_called": False,
        "one_case_per_packet": True,
    },
    "statistics": {
        "eligible_routes": len(eligible),
        "packets": len(packets),
        "case_type_counts": dict(__import__("collections").Counter(p["case_type"] for p in packets)),
    },
    "packets": packets,
}

assert len({p["packet_id"] for p in packets}) == len(packets)
assert len({p["route_id"] for p in packets}) == len(packets)

save_json(result, PACKETS_PATH)
print(json.dumps(result["statistics"], ensure_ascii=False, indent=2))
print("Saved:", PACKETS_PATH)
