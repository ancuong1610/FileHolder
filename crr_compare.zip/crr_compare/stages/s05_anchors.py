"""Auto-converted from 05_reconstruct_provisional_anchors_v4_restored.ipynb (code cells only)."""
from crr_compare.common import find_project_root, get_page_number, set_page_number

# ---- cell 1 ----

import copy
import json
import re
import time
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

STEP5_VERSION = "4.0.0-restored-provisional-anchors"
INPUT_SCHEMA_VERSION = "0.2.0"
OUTPUT_SCHEMA_VERSION = "0.3.0"

RECENT_ANCHOR_WINDOW = 6

STRUCTURAL_ELEMENT_TYPES = {"heading", "title"}
LAYOUT_ELEMENT_TYPES = {"header", "footer", "page_number"}

# Generic margin-marker morphology, e.g. M8, VC2, C9.
MARKER_PATTERN = re.compile(
    r"^(?=.{1,12}$)(?=.*[A-Za-z])(?=.*\d)[A-Za-z0-9]+$"
)
MARKER_MARGIN_RATIO = 0.16
MIN_MARKER_CANDIDATES = 5
MIN_MARKER_PAGES = 3

# Broad numbered legal/structural labels.
LEXICAL_LABEL = re.compile(
    r"^\s*(?P<kind>"
    r"Anhang|Anlage|Annex|"
    r"Teil|Part|"
    r"Titel|Title|"
    r"Kapitel|Chapter|"
    r"Abschnitt|Section|"
    r"Unterabschnitt|Subsection|"
    r"Artikel|Article"
    r")\s+(?P<label>[0-9A-Za-zIVXLC.-]+)\b",
    re.IGNORECASE,
)

# Used only to flag weak prefixes, not to promote them automatically.
WEAK_NUMBERED_PREFIX = re.compile(
    r"^\s*\d{1,4}[.)]\s+"
)

KEY_WHITESPACE = re.compile(r"\s+")

KEY_TRANSLATION = str.maketrans({
    "\u2018": "'", "\u2019": "'", "\u201a": "'", "\u201b": "'",
    "\u201c": '"', "\u201d": '"', "\u201e": '"', "\u201f": '"',
    "\u00ab": '"', "\u00bb": '"',
    "\u2010": "-", "\u2011": "-", "\u2012": "-", "\u2013": "-",
    "\u2014": "-", "\u2212": "-",
})


PROJECT_ROOT = find_project_root()
OUTPUT_DIR = PROJECT_ROOT / "output"

DOCUMENTS = {
    "old": {
        "input": OUTPUT_DIR / "old_document_normalized.json",
        "output": OUTPUT_DIR / "old_document_structured.json",
    },
    "new": {
        "input": OUTPUT_DIR / "new_document_normalized.json",
        "output": OUTPUT_DIR / "new_document_structured.json",
    },
}

print("Step 5 version:", STEP5_VERSION)
for label, paths in DOCUMENTS.items():
    print(f"{label.upper()}: {paths['input']} -> {paths['output']}")

# ---- cell 3 ----
def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise TypeError(f"{path} must contain a JSON object.")
    return value


def save_json(value: dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    temporary.replace(path)


def document_from(model: dict[str, Any]) -> dict[str, Any]:
    document = model.get("document")
    if not isinstance(document, dict):
        raise ValueError("Expected model['document'].")
    elements = document.get("elements")
    if not isinstance(elements, list) or not elements:
        raise ValueError("Expected non-empty document.elements.")
    return document


def validate_step4_model(model: dict[str, Any], path: Path) -> None:
    if model.get("schema_version") != INPUT_SCHEMA_VERSION:
        raise ValueError(
            f"Expected schema {INPUT_SCHEMA_VERSION!r}; "
            f"got {model.get('schema_version')!r} in {path}."
        )

    document = document_from(model)
    processing = model.get("processing") or {}
    internal = processing.get("internal_schema") or {}
    normalization = processing.get("normalization") or {}

    if internal.get("version") != "3.0.0":
        raise ValueError(
            "Step 5 requires the neutral Step-3 v3 evidence model."
        )

    if not normalization:
        raise ValueError("Step 5 requires Step-4 normalized input.")

    for element in document["elements"]:
        if not isinstance(element.get("normalized_text"), str):
            raise ValueError(
                f"Missing normalized_text for {element.get('element_id')}."
            )
        if not isinstance(element.get("reading_order"), int):
            raise ValueError(
                f"Missing reading_order for {element.get('element_id')}."
            )


source_models = {
    label: load_json(paths["input"])
    for label, paths in DOCUMENTS.items()
}

for label, model in source_models.items():
    validate_step4_model(model, DOCUMENTS[label]["input"])
    print(
        f"{label.upper()}: "
        f"{len(document_from(model)['elements']):,} elements loaded"
    )

# ---- cell 5 ----
def canonical_key_text(text: str) -> str:
    value = unicodedata.normalize("NFC", text)
    value = value.translate(KEY_TRANSLATION)
    value = KEY_WHITESPACE.sub(" ", value)
    return value.strip().casefold()


def page_width_map(document: dict[str, Any]) -> dict[int, float]:
    result = {}
    for page in document.get("pages") or []:
        if not isinstance(page, dict):
            continue
        page_no = page.get("page_number")
        width = page.get("width")
        if isinstance(page_no, int) and isinstance(width, (int, float)):
            result[page_no] = float(width)
    return result


def left_margin_ratio(
    element: dict[str, Any],
    widths: dict[int, float],
) -> float | None:
    polygon = element.get("primary_polygon")
    page = element.get("primary_page")
    width = widths.get(page)

    if (
        not isinstance(polygon, list)
        or not isinstance(width, (int, float))
        or width <= 0
    ):
        return None

    xs = polygon[0::2]
    if not xs or not all(isinstance(x, (int, float)) for x in xs):
        return None

    return min(float(x) for x in xs) / width


def detect_repeated_margin_marker_cohort(
    document: dict[str, Any],
) -> tuple[set[str], set[str], dict[str, Any]]:
    widths = page_width_map(document)
    candidates = []

    for element in document["elements"]:
        if not element.get("comparison_eligible"):
            continue
        if element.get("element_type") == "table":
            continue

        text = str(
            element.get("normalized_text")
            or element.get("text")
            or ""
        ).strip()

        ratio = left_margin_ratio(element, widths)

        if (
            MARKER_PATTERN.fullmatch(text)
            and ratio is not None
            and ratio <= MARKER_MARGIN_RATIO
        ):
            candidates.append(element)

    pages = {
        element.get("primary_page")
        for element in candidates
        if element.get("primary_page") is not None
    }

    enabled = (
        len(candidates) >= MIN_MARKER_CANDIDATES
        and len(pages) >= MIN_MARKER_PAGES
    )

    marker_ids = (
        {str(element["element_id"]) for element in candidates}
        if enabled else set()
    )

    marker_texts = (
        {
            str(
                element.get("normalized_text")
                or element.get("text")
                or ""
            ).strip()
            for element in candidates
        }
        if enabled else set()
    )
    marker_texts.discard("")

    profile = {
        "enabled": enabled,
        "candidate_count": len(candidates),
        "distinct_pages": len(pages),
        "pattern": MARKER_PATTERN.pattern,
        "margin_ratio_max": MARKER_MARGIN_RATIO,
        "marker_text_count": len(marker_texts),
    }

    return marker_ids, marker_texts, profile


def lexical_label_metadata(text: str) -> dict[str, str] | None:
    match = LEXICAL_LABEL.match(text)
    if not match:
        return None

    label = match.group(0).strip()
    kind = match.group("kind").casefold()

    return {
        "kind": kind,
        "label": label,
        "key": f"label:{canonical_key_text(label).replace(' ', ':', 1)}",
    }


def anchor_evidence(
    element: dict[str, Any],
    marker_ids: set[str],
) -> tuple[dict[str, Any] | None, str | None]:
    if not element.get("comparison_eligible"):
        return None, "comparison_ineligible_or_layout_element"

    if element.get("element_type") in LAYOUT_ELEMENT_TYPES:
        return None, "comparison_ineligible_or_layout_element"

    if element.get("element_type") == "table":
        return None, "no_anchor_evidence"

    if str(element.get("element_id")) in marker_ids:
        return None, "marker_like_heading_needs_review"

    text = str(
        element.get("normalized_text")
        or element.get("text")
        or ""
    ).strip()

    if not text:
        return None, "no_anchor_evidence"

    lexical = lexical_label_metadata(text)
    role = element.get("original_role")
    element_type = element.get("element_type")
    di_heading = (
        role in {"sectionHeading", "title"}
        or element_type in STRUCTURAL_ELEMENT_TYPES
    )

    # Exact numbered label + DI heading: strongest provisional evidence.
    if lexical and di_heading:
        lexical_only = canonical_key_text(text) == canonical_key_text(
            lexical["label"]
        )
        if lexical_only:
            return {
                "anchor_type": "di_heading_with_lexical_label",
                "confidence": "high",
                "anchor_key": f"heading-label:{canonical_key_text(text)}",
            }, None

        # Heading with title text after the legal label.
        return {
            "anchor_type": "di_heading",
            "confidence": "medium",
            "anchor_key": f"heading:{canonical_key_text(text)}",
        }, None

    # Numbered legal label without reliable DI role.
    if lexical:
        return {
            "anchor_type": "lexical_numbered_label",
            "confidence": "low",
            "anchor_key": lexical["key"],
        }, None

    # DI heading without numbered legal label.
    if di_heading:
        return {
            "anchor_type": "di_heading",
            "confidence": "medium",
            "anchor_key": f"heading:{canonical_key_text(text)}",
        }, None

    if WEAK_NUMBERED_PREFIX.match(text):
        return None, "weak_lexical_prefix"

    return None, "no_anchor_evidence"


def strip_detected_marker_prefix(
    text: str,
    marker_texts: set[str],
) -> tuple[str, str | None]:
    value = text.strip()

    if not value or not marker_texts:
        return value, None

    # Longest known detected marker first.
    for marker in sorted(marker_texts, key=len, reverse=True):
        if not marker:
            continue

        prefix = marker + " "
        if value.startswith(prefix):
            stripped = value[len(prefix):].lstrip()
            if stripped:
                return stripped, marker

    return value, None

# ---- cell 7 ----
def reconstruct_provisional_context(
    source_model: dict[str, Any],
) -> dict[str, Any]:
    result = copy.deepcopy(source_model)
    result["schema_version"] = OUTPUT_SCHEMA_VERSION

    document = document_from(result)
    elements = document["elements"]

    marker_ids, marker_texts, marker_profile = (
        detect_repeated_margin_marker_cohort(document)
    )

    anchors = []
    rejected = Counter()

    # First pass: create anchor records.
    for element in elements:
        evidence, rejected_reason = anchor_evidence(
            element,
            marker_ids,
        )

        if evidence is None:
            if rejected_reason:
                rejected[rejected_reason] += 1
            continue

        anchor_id = (
            f"{document.get('document_id')}-"
            f"A{len(anchors) + 1:05d}"
        )

        anchor = {
            "anchor_id": anchor_id,
            "element_id": element["element_id"],
            "reading_order": element.get("reading_order"),
            "primary_page": element.get("primary_page"),
            "anchor_type": evidence["anchor_type"],
            "confidence": evidence["confidence"],
            "anchor_key": evidence["anchor_key"],
            "text": element.get("text"),
            "normalized_text": element.get("normalized_text"),
            "context_is_authoritative_hierarchy": False,
        }
        anchors.append(anchor)

    anchor_by_order = {
        int(anchor["reading_order"]): anchor
        for anchor in anchors
        if isinstance(anchor.get("reading_order"), int)
    }

    # Second pass: each element receives a rolling window of recent
    # provisional anchors. No hierarchy is inferred.
    recent_anchor_ids: list[str] = []
    marker_prefix_removed = 0

    for element in elements:
        reading_order = int(element["reading_order"])

        # Anchor element itself becomes current before context is attached.
        anchor_here = anchor_by_order.get(reading_order)
        if anchor_here is not None:
            recent_anchor_ids.append(anchor_here["anchor_id"])
            recent_anchor_ids = recent_anchor_ids[-RECENT_ANCHOR_WINDOW:]

        nearest_id = (
            recent_anchor_ids[-1]
            if recent_anchor_ids
            else None
        )

        nearest_anchor = None
        if nearest_id is not None:
            # Anchor count is small enough for a one-time map.
            nearest_anchor = next(
                (
                    anchor
                    for anchor in anchors
                    if anchor["anchor_id"] == nearest_id
                ),
                None,
            )

        element["provisional_anchor_context"] = {
            "nearest_anchor_id": nearest_id,
            "nearest_anchor_confidence": (
                nearest_anchor.get("confidence")
                if nearest_anchor else None
            ),
            "recent_anchor_ids": list(recent_anchor_ids),
            "context_is_authoritative_hierarchy": False,
        }

        base_text = str(
            element.get("normalized_text")
            or element.get("text")
            or ""
        )

        comparison_text, stripped_marker = (
            strip_detected_marker_prefix(
                base_text,
                marker_texts,
            )
        )

        element["comparison_text"] = comparison_text
        element["comparison_text_flags"] = (
            ["detected_margin_marker_prefix_removed"]
            if stripped_marker else []
        )
        element["comparison_marker_prefix_removed"] = stripped_marker

        if stripped_marker:
            marker_prefix_removed += 1

    document["provisional_anchors"] = anchors

    statistics = document.setdefault("statistics", {})
    statistics["provisional_anchors"] = len(anchors)
    statistics["comparison_text_marker_prefixes_removed"] = (
        marker_prefix_removed
    )
    statistics["provisional_anchor_rejected_evidence"] = dict(
        sorted(rejected.items())
    )

    processing = result.setdefault("processing", {})
    processing["section_reconstruction"] = {
        "version": STEP5_VERSION,
        "strategy": "provisional_anchor_evidence",
        "authoritative_hierarchy_created": False,
        "provisional_context_only": True,
        "recent_anchor_window": RECENT_ANCHOR_WINDOW,
        "comparison_text_created": True,
        "comparison_text_marker_prefix_filtering": True,
        "margin_marker_profile": marker_profile,
    }

    return result


structured_models = {
    label: reconstruct_provisional_context(model)
    for label, model in source_models.items()
}

# ---- cell 9 ----
def validate_structured_model(
    source: dict[str, Any],
    result: dict[str, Any],
) -> None:
    source_document = document_from(source)
    result_document = document_from(result)

    assert result.get("schema_version") == OUTPUT_SCHEMA_VERSION

    reconstruction = (
        (result.get("processing") or {})
        .get("section_reconstruction") or {}
    )

    assert reconstruction.get("strategy") == "provisional_anchor_evidence"
    assert reconstruction.get("authoritative_hierarchy_created") is False
    assert reconstruction.get("comparison_text_created") is True

    before = source_document["elements"]
    after = result_document["elements"]

    assert len(before) == len(after) > 0

    immutable_fields = (
        "element_id",
        "element_type",
        "text",
        "normalized_text",
        "spans",
        "bounding_regions",
        "primary_page",
        "primary_polygon",
        "reading_order",
        "comparison_eligible",
        "exclusion_reasons",
        "extraction_validation",
        "represented_by_table_id",
        "table",
    )

    for old, new in zip(before, after):
        for field in immutable_fields:
            assert old.get(field) == new.get(field), (
                f"Step 5 changed {field} for "
                f"{old.get('element_id')}"
            )

        context = new.get("provisional_anchor_context")
        assert isinstance(context, dict)
        assert isinstance(context.get("recent_anchor_ids"), list)
        assert context.get("context_is_authoritative_hierarchy") is False

        assert isinstance(new.get("comparison_text"), str)
        assert isinstance(new.get("comparison_text_flags"), list)

    anchors = result_document.get("provisional_anchors")
    assert isinstance(anchors, list)

    anchor_ids = [a["anchor_id"] for a in anchors]
    assert len(anchor_ids) == len(set(anchor_ids))

    valid_anchor_ids = set(anchor_ids)

    for element in after:
        context = element["provisional_anchor_context"]
        for anchor_id in context["recent_anchor_ids"]:
            assert anchor_id in valid_anchor_ids

    print(
        f"Passed: {len(after):,} elements, "
        f"{len(anchors):,} provisional anchors."
    )


for label in DOCUMENTS:
    print(label.upper())
    validate_structured_model(
        source_models[label],
        structured_models[label],
    )

# ---- cell 11 ----
for label, paths in DOCUMENTS.items():
    save_json(
        structured_models[label],
        paths["output"],
    )

    document = document_from(structured_models[label])
    anchors = document.get("provisional_anchors") or []
    rejected = (
        document.get("statistics", {})
        .get("provisional_anchor_rejected_evidence", {})
    )

    print()
    print(
        f"{document.get('document_id')}: "
        f"{len(anchors):,} provisional anchors"
    )

    for anchor in anchors[:15]:
        print({
            "id": anchor["anchor_id"],
            "page": anchor.get("primary_page"),
            "type": anchor["anchor_type"],
            "confidence": anchor["confidence"],
            "text": str(anchor.get("normalized_text") or "")[:180],
            "key": anchor["anchor_key"],
        })

    print("Rejected evidence:", rejected)
    print("Saved:", paths["output"])
