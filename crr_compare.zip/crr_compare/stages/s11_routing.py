"""Auto-converted from 11_review_routing_special_cases_v2_1_selective_llm.ipynb (code cells only)."""
from crr_compare.common import find_project_root, get_page_number, set_page_number

# ---- cell 1 ----
import json, re
from collections import Counter
from pathlib import Path
from typing import Any

STEP11_VERSION = "2.1.0-selective-llm-routing"
EXPECTED_STEP9_STAGE = "movement_and_structural_reconciliation_evidence"
EXPECTED_STEP10_STAGE = "logical_table_comparison_with_provisional_context"

NON_TABLE_GROUPS = (
    "modified",
    "modified_review",
    "duplicate_exact_review",
    "relocated",
    "deleted",
    "added",
)
MARKER_RE = re.compile(r"^(?:[A-Z]{0,3}\d+[A-Z0-9]*|[A-Z]\d+)$", re.I)
ARTICLE_PREFIX_RE = re.compile(r"^(?:Artikel|Article)\s+\d+[A-Za-z]*\b", re.I)

# ---- cell 2 ----
PROJECT_ROOT = find_project_root()
OUTPUT_DIR = PROJECT_ROOT / "output"

STEP9_PATH = OUTPUT_DIR / "comparison_candidates_with_movement.json"
STEP10_PATH = OUTPUT_DIR / "table_comparison_result.json"
OUTPUT_PATH = OUTPUT_DIR / "review_routing.json"

def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        value = json.load(f)
    if not isinstance(value, dict):
        raise TypeError(f"{path} must contain a JSON object.")
    return value

def save_json(value: dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write("\n")
    tmp.replace(path)

movement = load_json(STEP9_PATH)
tables = load_json(STEP10_PATH)

if movement.get("comparison_stage") != EXPECTED_STEP9_STAGE:
    raise ValueError("Step 11 v2 requires the current Step 9 result.")
if tables.get("comparison_stage") != EXPECTED_STEP10_STAGE:
    raise ValueError("Step 11 v2 requires the current Step 10 result.")

print("Loaded Step 9 + Step 10.")

# ---- cell 3 ----
def text_of(element: dict[str, Any] | None) -> str:
    if not isinstance(element, dict):
        return ""
    for key in ("comparison_text", "normalized_text", "text"):
        value = element.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""

def token_changes(candidate: dict[str, Any]) -> list[dict[str, Any]]:
    diff = candidate.get("token_diff") or {}
    comparison = diff.get("comparison_token_diff") or {}
    return comparison.get("changes") or []

def element_requires_review(element: dict[str, Any] | None) -> bool:
    if not isinstance(element, dict):
        return False
    validation = element.get("extraction_validation") or {}
    return bool(validation.get("requires_extraction_review"))

def word_split_like(candidate: dict[str, Any]) -> bool:
    changes = token_changes(candidate)
    if len(changes) != 1:
        return False
    change = changes[0]
    old_tokens = change.get("old_tokens") or []
    new_tokens = change.get("new_tokens") or []
    old_join = "".join(old_tokens).casefold()
    new_join = "".join(new_tokens).casefold()
    return bool(old_join and old_join == new_join and old_tokens != new_tokens)


def wrap_artifact_like(candidate: dict[str, Any]) -> bool:
    """True when the whole diff is hyphenation/wrap-position only.

    Joins ALL changed tokens on each side across every diff operation and
    strips punctuation before comparing: equal alphanumeric content with
    different token boundaries means DI line-wrap hyphens / spacing moved.
    Catches multi-operation cases that word_split_like (single-op) misses.
    """
    changes = token_changes(candidate)
    if not changes:
        return False
    old_join = "".join(
        token for change in changes for token in (change.get("old_tokens") or [])
    )
    new_join = "".join(
        token for change in changes for token in (change.get("new_tokens") or [])
    )
    strip = lambda value: re.sub(r"[\W_]+", "", value).casefold()  # noqa: E731
    old_join, new_join = strip(old_join), strip(new_join)
    return bool(old_join) and old_join == new_join

def marker_only_like(candidate: dict[str, Any]) -> bool:
    changes = token_changes(candidate)
    if not changes or len(changes) > 2:
        return False
    changed = []
    for ch in changes:
        changed += list(ch.get("old_tokens") or [])
        changed += list(ch.get("new_tokens") or [])
    changed = [t for t in changed if str(t).strip()]
    return bool(changed) and all(MARKER_RE.match(str(t)) for t in changed)

def heading_boundary_like(candidate: dict[str, Any]) -> bool:
    old = candidate.get("old") or {}
    new = candidate.get("new") or {}
    if old.get("element_type") not in {"heading", "title"}:
        return False
    a, b = text_of(old), text_of(new)
    if not a or not b or a == b:
        return False
    shorter, longer = (a,b) if len(a) < len(b) else (b,a)
    if shorter in longer:
        fragment = longer.replace(shorter, "", 1).strip(" -–—:;,")
        return bool(fragment) and (
            ARTICLE_PREFIX_RE.match(fragment) is not None
            or len(fragment.split()) <= 4
        )
    return False

def short_text(candidate: dict[str, Any]) -> bool:
    texts = [text_of(candidate.get("old")), text_of(candidate.get("new"))]
    nonempty = [t for t in texts if t]
    return bool(nonempty) and min(len(t) for t in nonempty) < 40

def route_non_table(
    group: str,
    candidate: dict[str, Any],
) -> tuple[str, str, list[str]]:
    reasons = list(candidate.get("review_reasons") or [])
    old = candidate.get("old")
    new = candidate.get("new")

    source_extraction_review = (
        element_requires_review(old)
        or element_requires_review(new)
    )
    if source_extraction_review:
        reasons.append("source_extraction_requires_review")

    # ------------------------------------------------------------
    # Non-semantic / assignment-only cases
    # ------------------------------------------------------------

    if group == "relocated":
        return (
            "NON_SEMANTIC",
            "relocated_unchanged",
            sorted(set(reasons)),
        )

    if group == "duplicate_exact_review":
        reasons.append("duplicate_exact_assignment_ambiguous")
        return (
            "HUMAN_REVIEW",
            "duplicate_exact_assignment",
            sorted(set(reasons)),
        )

    # ------------------------------------------------------------
    # Deterministic special-case rules
    # ------------------------------------------------------------

    # Hyphenation/wrap-position-only differences are extraction artifacts,
    # never substantive changes. Checked before the single-op word-split rule
    # because it also covers multi-operation diffs.
    if wrap_artifact_like(candidate):
        reasons.append("hyphenation_wrap_position_only")
        return (
            "SPECIAL_CASE_RULE",
            "hyphenation_wrap_artifact",
            sorted(set(reasons)),
        )

    if word_split_like(candidate):
        reasons.append("possible_extraction_word_split")
        return (
            "SPECIAL_CASE_RULE",
            "possible_extraction_word_split",
            sorted(set(reasons)),
        )

    if marker_only_like(candidate):
        reasons.append("possible_marker_only_difference")
        return (
            "SPECIAL_CASE_RULE",
            "possible_marker_or_version_marker_difference",
            sorted(set(reasons)),
        )

    # Heading/title boundary differences such as
    #   "Artikel 19 <title>"  <->  "<title>"
    # are structural evidence. They should not consume an LLM call
    # merely because one side carries an Article prefix.
    if heading_boundary_like(candidate):
        reasons.append("possible_structural_heading_boundary")
        return (
            "SPECIAL_CASE_RULE",
            "structural_heading_boundary",
            sorted(set(reasons)),
        )

    if candidate.get("comparison_token_equivalent"):
        reasons.append(
            "comparison_token_equivalent_despite_text_difference"
        )
        return (
            "SPECIAL_CASE_RULE",
            "tokenization_neutral_difference",
            sorted(set(reasons)),
        )

    # ------------------------------------------------------------
    # Modified-review candidates
    # ------------------------------------------------------------
    #
    # These already survived matching and were explicitly withheld
    # from automatic acceptance upstream. Semantic evaluation can
    # genuinely help here.
    # ------------------------------------------------------------

    if group == "modified_review":
        return (
            "SPECIAL_CASE_LLM_OPTIONAL",
            "ambiguous_modified_pair",
            sorted(set(reasons)),
        )

    # ------------------------------------------------------------
    # One-sided ADD / DELETE candidates
    # ------------------------------------------------------------
    #
    # v2.0 over-routed every short/structural one-sided element.
    # That created 669 unnecessary LLM packets.
    #
    # Short text or heading status alone is NOT ambiguity evidence.
    # A heading such as "Artikel 105a" may simply be a real addition.
    #
    # Only positive review evidence routes a one-sided candidate to
    # optional LLM evaluation.
    # ------------------------------------------------------------

    if group in {"deleted", "added"}:
        if source_extraction_review or reasons:
            reasons.append(
                "one_sided_candidate_has_positive_review_evidence"
            )
            return (
                "SPECIAL_CASE_LLM_OPTIONAL",
                f"{group}_candidate_with_review_evidence",
                sorted(set(reasons)),
            )

        return (
            "ACCEPT_DETERMINISTIC",
            f"{group}_candidate",
            sorted(set(reasons)),
        )

    # ------------------------------------------------------------
    # Automatically accepted modified candidates
    # ------------------------------------------------------------

    if group == "modified":
        # If upstream attached explicit review evidence despite the
        # candidate living in modified, preserve that ambiguity.
        if source_extraction_review or reasons:
            return (
                "SPECIAL_CASE_LLM_OPTIONAL",
                "modified_with_review_evidence",
                sorted(set(reasons)),
            )

        return (
            "ACCEPT_DETERMINISTIC",
            "substantive_modified_candidate",
            sorted(set(reasons)),
        )

    return (
        "HUMAN_REVIEW",
        "unclassified_non_table_case",
        sorted(set(reasons)),
    )

# ---- cell 4 ----
non_table_routes = []
for group in NON_TABLE_GROUPS:
    for candidate in movement.get(group) or []:
        route, case_type, reasons = route_non_table(group, candidate)
        non_table_routes.append({
            "route_id": f"NT-{len(non_table_routes)+1:06d}",
            "source_kind": "non_table",
            "source_group": group,
            "candidate_id": candidate.get("candidate_id"),
            "route": route,
            "case_type": case_type,
            "review_reasons": reasons,
            "old_element_id": (candidate.get("old") or {}).get("element_id"),
            "new_element_id": (candidate.get("new") or {}).get("element_id"),
            "similarity": candidate.get("similarity"),
        })

# Evidence-only structural queues become explicit human/LLM review routes.
for item in movement.get("resegmentation_review") or []:
    non_table_routes.append({
        "route_id": f"NT-{len(non_table_routes)+1:06d}",
        "source_kind": "structural_evidence",
        "source_group": "resegmentation_review",
        "candidate_id": item.get("candidate_id") or item.get("review_id"),
        "route": "SPECIAL_CASE_RULE",
        "case_type": "resegmentation_suspect",
        "review_reasons": list(item.get("review_reasons") or []),
        "similarity": item.get("similarity"),
    })

for group, items, case_type in (
    ("movement_review", movement.get("movement_review") or [], "movement_block_review"),
    ("structural_split_merge_review", movement.get("structural_split_merge_review") or [], "structural_split_merge"),
    ("structural_boundary_review", movement.get("structural_boundary_review") or [], "structural_boundary"),
):
    for item in items:
        if group == "movement_review":
            route = "HUMAN_REVIEW"
        else:
            route = "SPECIAL_CASE_RULE"

        non_table_routes.append({
            "route_id": f"NT-{len(non_table_routes)+1:06d}",
            "source_kind": "structural_evidence",
            "source_group": group,
            "candidate_id": item.get("candidate_id") or item.get("review_id"),
            "route": route,
            "case_type": case_type,
            "review_reasons": list(item.get("review_reasons") or []),
        })

def route_table_match(match: dict[str, Any]) -> tuple[str,str,list[str]]:
    cls = match.get("classification")
    reasons = list(match.get("review_reasons") or [])
    if cls in {"UNCHANGED", "LAYOUT_EQUIVALENT"}:
        return "NON_SEMANTIC", "table_non_semantic", reasons
    if cls == "EXTRACTION_ARTIFACT_REVIEW":
        return "SPECIAL_CASE_RULE", "table_extraction_artifact", reasons
    if cls == "STRUCTURE_CHANGED_REVIEW":
        return "HUMAN_REVIEW", "table_structure_change", reasons
    if cls == "MODIFIED":
        if match.get("needs_review"):
            return "SPECIAL_CASE_LLM_OPTIONAL", "table_modified_with_review_evidence", reasons
        return "ACCEPT_DETERMINISTIC", "table_modified", reasons
    return "HUMAN_REVIEW", "unclassified_table_match", reasons

table_routes = []
for match in tables.get("table_matches") or []:
    route, case_type, reasons = route_table_match(match)
    table_routes.append({
        "route_id": f"TB-{len(table_routes)+1:06d}",
        "source_kind": "table_match",
        "source_group": "table_matches",
        "candidate_id": match.get("table_match_id"),
        "route": route,
        "case_type": case_type,
        "review_reasons": sorted(set(reasons)),
        "classification": match.get("classification"),
    })

for group, case_type in (
    ("deleted_table_candidates", "deleted_table_candidate"),
    ("added_table_candidates", "added_table_candidate"),
):
    for table in tables.get(group) or []:
        table_routes.append({
            "route_id": f"TB-{len(table_routes)+1:06d}",
            "source_kind": "table_residual",
            "source_group": group,
            "candidate_id": table.get("logical_table_id"),
            "route": "SPECIAL_CASE_LLM_OPTIONAL",
            "case_type": case_type,
            "review_reasons": ["one_sided_table_candidate"],
        })

for item in tables.get("unresolved_table_groups") or []:
    table_routes.append({
        "route_id": f"TB-{len(table_routes)+1:06d}",
        "source_kind": "table_review_group",
        "source_group": "unresolved_table_groups",
        "candidate_id": item.get("review_group_id"),
        "route": "HUMAN_REVIEW",
        "case_type": "unresolved_table_group",
        "review_reasons": [item.get("reason") or "unresolved_table_group"],
    })

# ---- cell 5 ----
all_routes = non_table_routes + table_routes
route_counts = Counter(item["route"] for item in all_routes)
case_counts = Counter(item["case_type"] for item in all_routes)

result = {
    "schema_version": "1.0.0",
    "comparison_stage": "deterministic_review_routing",
    "source_files": {
        "step9": STEP9_PATH.name,
        "step10": STEP10_PATH.name,
    },
    "processing": {
        "version": STEP11_VERSION,
        "llm_called": False,
        "matching_recomputed": False,
        "source_text_rewritten": False,
        "authoritative_hierarchy_used": False,
    },
    "statistics": {
        "route_counts": dict(route_counts),
        "case_type_counts": dict(case_counts),
        "total_routes": len(all_routes),
        "llm_optional_cases": route_counts["SPECIAL_CASE_LLM_OPTIONAL"],
        "human_review_cases": route_counts["HUMAN_REVIEW"],
        "llm_optional_fraction": round(
            route_counts["SPECIAL_CASE_LLM_OPTIONAL"] / max(1, len(all_routes)), 4
        ),
    },
    "non_table_routes": non_table_routes,
    "table_routes": table_routes,
}

# Every route_id must be unique.
route_ids = [x["route_id"] for x in all_routes]
assert len(route_ids) == len(set(route_ids))

save_json(result, OUTPUT_PATH)
print(json.dumps(result["statistics"], ensure_ascii=False, indent=2))
print("Saved:", OUTPUT_PATH)

# ---- cell 6 ----
print("\n=== LLM-OPTIONAL CASE TYPES ===")
llm_case_counts = Counter(
    item["case_type"]
    for item in all_routes
    if item["route"] == "SPECIAL_CASE_LLM_OPTIONAL"
)
print(json.dumps(dict(llm_case_counts), ensure_ascii=False, indent=2))

print("\n=== FIRST 25 LLM-OPTIONAL ROUTES ===")
for item in [
    x for x in all_routes
    if x["route"] == "SPECIAL_CASE_LLM_OPTIONAL"
][:25]:
    print(
        item["route_id"],
        "|",
        item["case_type"],
        "|",
        item.get("candidate_id"),
        "| reasons=",
        item.get("review_reasons"),
    )
