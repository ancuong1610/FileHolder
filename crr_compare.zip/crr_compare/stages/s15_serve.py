"""Stage 15 - Phase-2 serving index + manifest (LLM-ready).

Replaces notebook 15. Consumes the canonical comparison_result.json and the
Step-5 structured documents and writes:
- output/phase2_change_index.json  (rich units for downstream LLM/chat use)
- output/bu_comparison_review_manifest.json

The human-facing inline redline is produced separately by crr_compare/redline.py.
"""
import json
import re
from collections import Counter
from pathlib import Path

from crr_compare.common import find_project_root, output_dir

PROJECT_ROOT = find_project_root()
OUTPUT_DIR = output_dir(PROJECT_ROOT)

FINAL_PATH = OUTPUT_DIR / "comparison_result.json"
OLD_STRUCTURED_PATH = OUTPUT_DIR / "old_document_structured.json"
NEW_STRUCTURED_PATH = OUTPUT_DIR / "new_document_structured.json"
INDEX_PATH = OUTPUT_DIR / "phase2_change_index.json"
MANIFEST_PATH = OUTPUT_DIR / "bu_comparison_review_manifest.json"

comparison = json.loads(FINAL_PATH.read_text(encoding="utf-8"))
old_doc = json.loads(OLD_STRUCTURED_PATH.read_text(encoding="utf-8"))
new_doc = json.loads(NEW_STRUCTURED_PATH.read_text(encoding="utf-8"))

if comparison.get("comparison_stage") != "phase_1_final_comparison":
    raise SystemExit("Stage 15 requires canonical Step 14 comparison_result.json.")


# --- structure bucketing -----------------------------------------------------
STRUCTURE_LABEL_RE = re.compile(
    r"^\s*(?:Artikel|Article|Anhang|Anlage|Annex|Kapitel|Chapter|"
    r"Abschnitt|Section|Teil|Part|Titel|Title)\s+[0-9A-Za-zIVXLCDM.\-]+\s*$",
    re.IGNORECASE,
)


def display_text(element: dict) -> str:
    return str(element.get("text") or element.get("normalized_text") or "").strip()


def is_heading_like(element: dict) -> bool:
    if element.get("element_type") in {"heading", "title"}:
        return True
    text = display_text(element)
    # Short standalone structural labels may be typed as paragraphs by DI;
    # long cross-references ("Artikel 10 der Verordnung ...") never qualify.
    return bool(text) and len(text) <= 120 and bool(STRUCTURE_LABEL_RE.match(text))


def build_bucket_index(model: dict) -> dict[str, str]:
    """element_id -> current structural bucket label (reading order walk)."""
    buckets: dict[str, str] = {}
    current = "Front matter"
    elements = sorted(
        (model.get("document") or {}).get("elements") or [],
        key=lambda e: e.get("reading_order") if isinstance(e.get("reading_order"), int) else 10**12,
    )
    for element in elements:
        if is_heading_like(element):
            current = display_text(element)[:80]
        buckets[element.get("element_id")] = current
    return buckets


old_buckets = build_bucket_index(old_doc)
new_buckets = build_bucket_index(new_doc)


def bucket_for(change: dict) -> str:
    old = change.get("old") or {}
    new = change.get("new") or {}
    old_id = old.get("element_id")
    new_id = new.get("element_id")
    return (
        (old_buckets.get(old_id) if old_id else None)
        or (new_buckets.get(new_id) if new_id else None)
        or "Unassigned"
    )


def compact_diff_ops(token_diff: dict | None, field: str = "comparison_token_diff") -> list[dict]:
    ops = ((token_diff or {}).get(field) or {}).get("changes") or []
    return [
        {
            "operation": op.get("operation"),
            "old": " ".join(op.get("old_tokens") or []),
            "new": " ".join(op.get("new_tokens") or []),
        }
        for op in ops
    ]


units = []

for change in comparison.get("changes") or []:
    old = change.get("old") or {}
    new = change.get("new") or {}
    resolution = change.get("resolution") or {}
    units.append(
        {
            "unit_id": change["change_id"],
            "kind": "element",
            "bucket": bucket_for(change),
            "change_type": change.get("change_type"),
            "meaningful_status": resolution.get("status"),
            "needs_review": bool(resolution.get("needs_review")),
            "review_reasons": resolution.get("review_reasons") or [],
            "similarity": change.get("similarity"),
            "old": {
                "element_id": old.get("element_id"),
                "page": old.get("primary_page"),
                "text": old.get("text"),
            },
            "new": {
                "element_id": new.get("element_id"),
                "page": new.get("primary_page"),
                "text": new.get("text"),
            },
            "token_operations": compact_diff_ops(change.get("token_diff")),
        }
    )

for record in comparison.get("table_changes") or []:
    resolution = record.get("resolution") or {}
    old_t = record.get("old") or {}
    new_t = record.get("new") or {}
    changed_cells = [
        {
            "cell_ref": f"r{c.get('old_row_index')}/n{c.get('new_row_index')}c{c.get('column_index')}",
            "classification": c.get("classification"),
            "old_text": (c.get("old") or {}).get("text"),
            "new_text": (c.get("new") or {}).get("text"),
        }
        for c in (record.get("cell_changes") or [])
        if (c.get("classification") or "UNCHANGED") != "UNCHANGED"
    ]
    units.append(
        {
            "unit_id": record["table_change_id"],
            "kind": "table",
            "bucket": bucket_for(record),
            "change_type": record.get("change_type"),
            "classification": record.get("classification"),
            "meaningful_status": resolution.get("status"),
            "needs_review": bool(resolution.get("needs_review")),
            "review_reasons": record.get("review_reasons") or resolution.get("review_reasons") or [],
            "old": {
                "table_ids": old_t.get("source_table_ids") or [],
                "pages": old_t.get("source_pages") or [],
                "rows": old_t.get("row_count"),
                "columns": old_t.get("column_count"),
            },
            "new": {
                "table_ids": new_t.get("source_table_ids") or [],
                "pages": new_t.get("source_pages") or [],
                "rows": new_t.get("row_count"),
                "columns": new_t.get("column_count"),
            },
            "changed_cells": changed_cells[:200],
        }
    )

phase2 = {
    "schema_version": "1.1.0",
    "serving_stage": "phase2_change_index",
    "source_comparison_schema": comparison.get("schema_version"),
    "usage": {
        "purpose": "Grounding corpus for Phase-2 LLM chat over regulation changes.",
        "meaningful_status": {
            "accepted": "deterministically accepted substantive change",
            "review": "requires human or LLM confirmation",
            "non_semantic": "layout/movement artifact",
        },
    },
    "statistics": {
        "units": len(units),
        "by_change_type": dict(Counter(u["change_type"] for u in units)),
        "needs_review_units": sum(1 for u in units if u["needs_review"]),
        "review_queue_entries": len(comparison.get("review_queue") or []),
        "buckets": len({u["bucket"] for u in units}),
    },
    "review_queue_summary": [
        {
            "review_id": item.get("review_id"),
            "source_kind": item.get("source_kind"),
            "case_type": item.get("case_type"),
            "resolution": item.get("resolution"),
        }
        for item in comparison.get("review_queue") or []
    ],
    "change_units": units,
}

INDEX_PATH.write_text(json.dumps(phase2, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(f"Saved: {INDEX_PATH}")
print(json.dumps(phase2["statistics"], ensure_ascii=False, indent=2))

manifest = {
    "schema_version": "1.0.0",
    "source_comparison": FINAL_PATH.name,
    "phase2_index": INDEX_PATH.name,
    "redline_html": "bu_comparison_redline.html",
    "units": len(units),
    "changes": len(comparison.get("changes") or []),
    "table_changes": len(comparison.get("table_changes") or []),
}
MANIFEST_PATH.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(f"Saved: {MANIFEST_PATH}")

# BU triage export: the full review queue as CSV (opens directly in Excel).
import csv

CSV_PATH = OUTPUT_DIR / "review_queue_export.csv"
with CSV_PATH.open("w", encoding="utf-8-sig", newline="") as handle:
    writer = csv.writer(handle, delimiter=";")
    writer.writerow([
        "review_id", "source_kind", "case_type", "route", "status",
        "needs_review", "candidate_id", "similarity", "reasons",
        "old_element_ids", "new_element_ids",
    ])
    for item in comparison.get("review_queue") or []:
        resolution = item.get("resolution") or {}
        evidence = item.get("evidence") or {}
        writer.writerow([
            item.get("review_id"),
            item.get("source_kind"),
            item.get("case_type"),
            resolution.get("route"),
            resolution.get("status"),
            "ja" if resolution.get("needs_review") else "nein",
            item.get("source_candidate_id"),
            evidence.get("similarity"),
            "; ".join(
                (item.get("resolution") or {}).get("review_reasons")
                or evidence.get("review_reasons")
                or []
            ),
            "; ".join(evidence.get("old_element_ids") or []),
            "; ".join(evidence.get("new_element_ids") or []),
        ])
print(f"Saved: {CSV_PATH}")

from crr_compare.redline import render as render_redline

render_redline(PROJECT_ROOT)
print("Stage 15 complete.")
