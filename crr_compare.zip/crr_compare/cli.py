"""CLI runner for the CRR comparison pipeline."""
from __future__ import annotations

import argparse
import os
import runpy
import sys
import time
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))

STAGES = [
    ("01", "s01_extract.py"),
    ("02", "s02_validate_extraction.py"),
    ("03", "s03_internal_schema.py"),
    ("04", "s04_normalize.py"),
    ("05", "s05_anchors.py"),
    ("06", "s06_exact_matching.py"),
    ("07", "s07_modified_matching.py"),
    ("08", "s08_candidates.py"),
    ("09", "s09_movement.py"),
    ("10", "s10_tables.py"),
    ("11", "s11_routing.py"),
    ("12", "s12_packets.py"),
    ("13", "s13_llm_evaluator.py"),
    ("14", "s14_canonical_result.py"),
    ("15", "s15_serve.py"),
]


def stage_path(number: str) -> Path:
    for num, name in STAGES:
        if num == number:
            return REPO_ROOT / "crr_compare" / "stages" / name
    raise SystemExit(f"Unknown stage {number!r}")


def run_stages(numbers: list[str], root: Path) -> None:
    os.environ["CRR_PROJECT_ROOT"] = str(root)
    started = time.perf_counter()
    for number in numbers:
        path = stage_path(number)
        print(f"\n{'=' * 70}\nSTAGE {number}: {path.name}\n{'=' * 70}", flush=True)
        stage_start = time.perf_counter()
        try:
            runpy.run_path(str(path), run_name="__main__")
        except SystemExit as exc:
            if exc.code not in (0, None):
                raise SystemExit(f"Stage {number} failed with exit code {exc.code}") from exc
        print(f"--- stage {number} finished in {time.perf_counter() - stage_start:.1f}s")
    print(f"\nAll selected stages completed in {time.perf_counter() - started:.1f}s")


def parse_stage_range(args) -> list[str]:
    numbers = [num for num, _ in STAGES]
    start = args.from_stage or numbers[0]
    end = args.to_stage or numbers[-1]
    if start not in numbers or end not in numbers or numbers.index(start) > numbers.index(end):
        raise SystemExit(f"Invalid stage range {start}..{end}")
    return [num for num in numbers if numbers.index(start) <= numbers.index(num) <= numbers.index(end)]


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="crr_compare", description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    def common(p):
        p.add_argument("--root", type=Path, default=REPO_ROOT / "workspace",
                       help="Pipeline workspace root (default: ./workspace)")

    run_p = sub.add_parser("run", help="Run pipeline stages in order")
    common(run_p)
    run_p.add_argument("--from-stage", choices=[n for n, _ in STAGES])
    run_p.add_argument("--to-stage", choices=[n for n, _ in STAGES])

    eval_p = sub.add_parser("eval", help="Run identity + mutation evaluation suite")
    common(eval_p)
    eval_p.add_argument("--seed", type=int, default=42)
    eval_p.add_argument("--skip-identity", action="store_true")

    redline_p = sub.add_parser("redline", help="Regenerate the HTML redline only")
    common(redline_p)

    gt_p = sub.add_parser(
        "eval-gt",
        help="Score output against a BU ground-truth benchmark JSON",
    )
    common(gt_p)
    gt_p.add_argument("--gt", type=Path, default=REPO_ROOT / "test_data" / "GroundTruth.json")

    args = parser.parse_args(argv)
    root: Path = args.root.expanduser().resolve()

    if args.command == "run":
        run_stages(parse_stage_range(args), root)
    elif args.command == "redline":
        os.environ["CRR_PROJECT_ROOT"] = str(root)
        runpy.run_path(str(REPO_ROOT / "crr_compare" / "redline.py"), run_name="__main__")
    elif args.command == "eval":
        from crr_compare.evaluate import evaluate_command

        evaluate_command(root=root, seed=args.seed, skip_identity=args.skip_identity)
    elif args.command == "eval-gt":
        from crr_compare.gt_benchmark import run as run_gt

        run_gt(root, args.gt.expanduser().resolve())


if __name__ == "__main__":
    main()
