# Phase 1 runbook

Phase 1 compares two CRR PDF versions and produces a traceable structured
change result plus a whole-article BU review PDF. The canonical path uses the
neutral Step-3 schema and provisional-anchor Steps 5-9; it never treats those
anchors as an authoritative legal hierarchy.

## Environment

Use Python 3.11 or newer when possible:

```bash
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements.txt
```

The internal `bbk_ai_hub_sdk` package is required only for Azure extraction
through the TIA proxy and optional LLM cleanup. Install it from the approved
internal package source; do not add credentials to this directory.

Validate every notebook without running APIs or reading documents:

```bash
python3 run_phase1.py --validate-only
```

## Inputs and extraction

Place the two configured PDFs under `input/document/`. Configure the approved
TIA/Azure values in `.env`, then run the external extraction explicitly:

```bash
python3 run_phase1.py --include-extraction --from-step 1 --through-step 12
```

Step 1 caches page chunks and can resume. Step 2 writes content-free validation
reports. Review the Step-2 gate before relying on later comparison results.

## Deterministic comparison and PDF

When valid `old_di_raw.json`, `new_di_raw.json`, and validation reports already
exist under `output/`, run:

```bash
python3 run_phase1.py --from-step 3 --through-step 15
```

Primary deliverables:

- `output/comparison_result.json`
- `output/comparison_review_by_article.pdf`
- `output/comparison_review_by_article_manifest.json`

`07_modified_element_matching_refined.ipynb` is the incompatible legacy Step-7
branch and is intentionally excluded from the runner. `test_tia_phase2_capability.ipynb`
is a Phase-2 experiment and is also outside the Phase-1 execution path.

## Optional LLM cleanup

LLM cleanup is post-processing. It may suppress extraction/layout artifacts or
merge false deletion/addition pairs, but it must not discover new changes or
decide legal impact.

```bash
python3 run_phase1.py --llm-cleanup --from-step 3 --through-step 15
```

Invalid model responses retain the affected candidates visibly as `UNCERTAIN`.
The deterministic `comparison_result.json` remains the audit source.
