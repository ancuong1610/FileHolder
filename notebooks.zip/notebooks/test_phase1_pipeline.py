from __future__ import annotations

import ast
import json
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parent


def notebook_definitions(filename: str, assignments: set[str] | None = None) -> dict:
    notebook = json.loads((ROOT / filename).read_text(encoding="utf-8"))
    source = "\n".join(
        "".join(cell.get("source") or [])
        for cell in notebook["cells"]
        if cell.get("cell_type") == "code"
    )
    tree = ast.parse(source)
    body = [
        node
        for node in tree.body
        if isinstance(node, ast.ImportFrom) and node.module == "__future__"
    ]
    allowed = assignments or set()
    optional_modules = {"fitz", "pypdf", "reportlab"}
    for node in tree.body:
        if isinstance(node, ast.ImportFrom) and node.module == "__future__":
            continue
        if isinstance(node, ast.Import) and any(alias.name.split(".")[0] in optional_modules for alias in node.names):
            continue
        if isinstance(node, ast.ImportFrom) and (node.module or "").split(".")[0] in optional_modules:
            continue
        if isinstance(node, (ast.Import, ast.ImportFrom, ast.FunctionDef)):
            body.append(node)
        elif isinstance(node, ast.Assign):
            names = {target.id for target in node.targets if isinstance(target, ast.Name)}
            if names and names <= allowed:
                body.append(node)
    module = ast.Module(body=body, type_ignores=[])
    ast.fix_missing_locations(module)
    namespace: dict = {}
    exec(compile(module, filename, "exec"), namespace)
    return namespace


def element(
    element_id: str,
    text: str,
    order: int,
    page: int,
    anchor: str | None,
    unmatched_reason: str | None = None,
) -> dict:
    value = {
        "element_id": element_id,
        "element_type": "paragraph",
        "text": text,
        "normalized_text": text,
        "reading_order": order,
        "primary_page": page,
        "confidence": 0.99,
        "extraction_validation": {},
        "provisional_anchor_context": {
            "nearest_anchor_key": anchor,
            "recent_anchor_keys": [anchor] if anchor else [],
        },
    }
    if unmatched_reason:
        value["exact_unmatched_reason"] = unmatched_reason
    return value


class Phase1ContractTests(unittest.TestCase):
    def test_step8_v3_conservation_and_review_routing(self) -> None:
        ns = notebook_definitions(
            "08_build_comparison_candidates.ipynb",
            {"TOKEN_PATTERN", "LINE_WRAP_HYPHEN_PATTERN", "WHITESPACE_PATTERN"},
        )
        ns["EXACT_MATCHES_PATH"] = Path("exact_element_matches.json")
        ns["MODIFIED_MATCHES_PATH"] = Path("modified_element_matches.json")

        old_exact = element("o1", "same", 1, 1, "label:artikel:1")
        new_exact = element("n1", "same", 2, 2, "label:artikel:1")
        old_modified = element("o2", "capital requirement is 8 percent", 3, 2, "label:artikel:1")
        new_modified = element("n2", "capital requirement is 9 percent", 3, 2, "label:artikel:1")
        old_residual = element("o3", "ambiguous old", 4, 3, None, "duplicate_context_ambiguous")
        new_residual = element("n3", "new clause", 4, 3, "label:artikel:2")

        exact = {
            "schema_version": "0.2.0",
            "comparison_stage": "exact_element_matching_with_provisional_context",
            "old_document": {"document_id": "old", "page_count": 3},
            "new_document": {"document_id": "new", "page_count": 3},
            "statistics": {"old_comparable_elements": 3, "new_comparable_elements": 3},
            "matches": [{
                "match_id": "EXACT-1",
                "match_type": "exact",
                "match_method": "global",
                "old": old_exact,
                "new": new_exact,
            }],
            "unmatched_old": [old_modified, old_residual],
            "unmatched_new": [new_modified, new_residual],
        }
        modified = {
            "schema_version": "0.3.0",
            "comparison_stage": "modified_element_matching_with_provisional_context",
            "old_document": exact["old_document"],
            "new_document": exact["new_document"],
            "modified_matches": [{
                "match_id": "MODIFIED-1",
                "match_type": "modified_alignment_candidate",
                "match_method": "reciprocal_similarity_alignment",
                "similarity": 0.9,
                "similarity_evidence": {"score": 0.9},
                "needs_review": False,
                "review_reasons": [],
                "old": old_modified,
                "new": new_modified,
            }],
            "review_pairs": [],
            "unmatched_old": [old_residual],
            "unmatched_new": [new_residual],
        }

        result = ns["build_comparison_candidates"](exact, modified)
        self.assertEqual(result["schema_version"], "0.2.0")
        self.assertEqual(result["comparison_stage"], "comparison_candidate_assembly_with_provisional_context")
        self.assertEqual(
            [len(result[name]) for name in ("unchanged", "modified", "deleted", "added")],
            [1, 1, 1, 1],
        )
        self.assertEqual(
            result["modified"][0]["token_diff"]["layout_normalized_token_diff"]["change_operation_count"],
            1,
        )
        self.assertTrue(result["deleted"][0]["needs_review"])
        self.assertIn("deferred_exact_duplicate_ambiguity", result["deleted"][0]["review_reasons"])

        old_ids = ns["element_ids"](
            result["unchanged"] + result["modified"] + result["paired_review"] + result["deleted"],
            "old",
        )
        new_ids = ns["element_ids"](
            result["unchanged"] + result["modified"] + result["paired_review"] + result["added"],
            "new",
        )
        self.assertEqual(len(old_ids), len(set(old_ids)))
        self.assertEqual(len(new_ids), len(set(new_ids)))
        self.assertEqual(len(old_ids), 3)
        self.assertEqual(len(new_ids), 3)

    def test_flat_provisional_anchor_is_not_a_hierarchy(self) -> None:
        movement = notebook_definitions("09_detect_moved_sections_refined.ipynb")
        table = notebook_definitions("10_compare_tables_refined.ipynb")
        value = {
            "provisional_anchor_context": {
                "nearest_anchor_key": "label:artikel:4",
                "recent_anchor_keys": ["heading:part", "label:artikel:4"],
            }
        }
        self.assertEqual(movement["raw_semantic_anchor"](value), ("label:artikel:4",))
        self.assertEqual(table["stable_anchor"](value, {}), ("label:artikel:4",))

    def test_pdf_article_grouping_uses_step5_anchor_evidence(self) -> None:
        pdf = notebook_definitions(
            "15_generate_structured_bu_review_pdf (3).ipynb",
            {"ARTICLE_PATTERN"},
        )
        pdf["ANCHOR_BY_ID"] = {
            "A1": {"anchor_id": "A1", "anchor_text": "Artikel 4 Own funds"},
        }
        value = {
            "provisional_anchor_context": {
                "nearest_anchor_id": "A1",
                "recent_anchor_ids": ["A1"],
            }
        }
        self.assertEqual(pdf["article_identity"](value), ("artikel 4", "Artikel 4"))


if __name__ == "__main__":
    unittest.main()
