#!/usr/bin/env python3
"""Run and validate the canonical Phase-1 notebook pipeline without Jupyter.

The runner executes each notebook in a fresh Python process so hidden kernel
state cannot leak between stages. External extraction and LLM cleanup are
explicit opt-ins.
"""

from __future__ import annotations

import __future__
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
from typing import Iterable


PROJECT_ROOT = Path(__file__).resolve().parent
OUTPUT_DIR = PROJECT_ROOT / "output"

STAGES = {
    1: "01_test_document_intelligence_chunked.ipynb",
    2: "02_inspect_extraction.ipynb",
    3: "03_build_internal_schema_neutral_v3.ipynb",
    4: "04_normalize_content.ipynb",
    5: "05_reconstruct_provisional_anchors_v3 (1).ipynb",
    6: "06_exact_matching_provisional_context_v3.ipynb",
    7: "07_modified_matching_provisional_context_v3.ipynb",
    8: "08_build_comparison_candidates.ipynb",
    9: "09_detect_moved_sections_refined.ipynb",
    10: "10_compare_tables_refined.ipynb",
    11: "11_add_confidence_review_flags_refined.ipynb",
    12: "12_build_final_comparison_result_refined.ipynb",
    13: "13_build_llm_cleanup_packets.ipynb",
    14: "14_llm_cleanup_and_build_result.ipynb",
    15: "15_generate_structured_bu_review_pdf (3).ipynb",
}

LLM_STAGES = (13, 14)


def notebook_code(path: Path) -> Iterable[tuple[int, str]]:
    with path.open("r", encoding="utf-8") as handle:
        notebook = json.load(handle)
    if notebook.get("nbformat") != 4 or not isinstance(notebook.get("cells"), list):
        raise ValueError(f"{path.name} is not a valid v4 notebook")
    for index, cell in enumerate(notebook["cells"]):
        if cell.get("cell_type") == "code":
            yield index, "".join(cell.get("source") or [])


def compile_notebook(path: Path) -> None:
    flags = __future__.annotations.compiler_flag
    for cell_index, source in notebook_code(path):
        compile(source, f"{path}:cell-{cell_index}", "exec", flags=flags, dont_inherit=True)


def execute_notebook(path: Path) -> None:
    namespace = {
        "__name__": "__main__",
        "__file__": str(path),
        "__package__": None,
    }
    flags = __future__.annotations.compiler_flag
    for cell_index, source in notebook_code(path):
        if not source.strip():
            continue
        try:
            code = compile(
                source,
                f"{path}:cell-{cell_index}",
                "exec",
                flags=flags,
                dont_inherit=True,
            )
            exec(code, namespace)
        except Exception as error:
            raise RuntimeError(f"{path.name} failed in code cell {cell_index}") from error


def validate_all() -> None:
    missing = []
    for stage, filename in STAGES.items():
        path = PROJECT_ROOT / filename
        if not path.exists():
            missing.append(f"Step {stage}: {filename}")
            continue
        compile_notebook(path)
    if missing:
        raise FileNotFoundError("Missing notebooks:\n" + "\n".join(missing))
    print(f"Validated {len(STAGES)} canonical Phase-1 notebooks.")


def selected_stages(args: argparse.Namespace) -> list[int]:
    if args.include_extraction:
        stages = list(range(1, 13))
    else:
        if args.from_step < 3:
            raise ValueError("Steps 1-2 require --include-extraction because they call Azure services.")
        stages = list(range(max(3, args.from_step), min(12, args.through_step) + 1))
    if args.llm_cleanup and args.through_step >= 14:
        stages.extend(LLM_STAGES)
    if args.through_step >= 15:
        stages.append(15)
    return [stage for stage in stages if args.from_step <= stage <= args.through_step]


def run_stage(stage: int, *, use_cleaned_result: bool) -> None:
    path = PROJECT_ROOT / STAGES[stage]
    env = os.environ.copy()
    env["PHASE1_USE_LLM_CLEANUP"] = "1" if use_cleaned_result else "0"
    command = [sys.executable, str(Path(__file__).resolve()), "--execute-one", str(path)]
    print(f"\n=== Step {stage}: {path.name} ===", flush=True)
    subprocess.run(command, cwd=PROJECT_ROOT, env=env, check=True)


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--validate-only", action="store_true", help="Parse and compile every canonical notebook.")
    result.add_argument("--include-extraction", action="store_true", help="Run external Azure extraction and validation Steps 1-2.")
    result.add_argument("--llm-cleanup", action="store_true", help="Run optional internal-LLM cleanup Steps 13-14 and render the cleaned result.")
    result.add_argument("--from-step", type=int, default=3)
    result.add_argument("--through-step", type=int, default=15)
    result.add_argument("--execute-one", type=Path, help=argparse.SUPPRESS)
    return result


def main() -> int:
    args = parser().parse_args()
    if args.execute_one:
        execute_notebook(args.execute_one.resolve())
        return 0
    validate_all()
    if args.validate_only:
        return 0
    if not (1 <= args.from_step <= args.through_step <= 15):
        raise ValueError("Expected 1 <= --from-step <= --through-step <= 15")
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    stages = selected_stages(args)
    if not stages:
        raise ValueError("No stages selected")
    for stage in stages:
        run_stage(stage, use_cleaned_result=args.llm_cleanup and stage == 15)
    print("\nPhase-1 pipeline completed successfully.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
