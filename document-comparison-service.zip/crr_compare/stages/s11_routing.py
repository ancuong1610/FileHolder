"""Deterministic review routing (s11): generic base routing with optional CRR3 enrichment.

Auto-converted from 11_review_routing_special_cases_v2_1_selective_llm.ipynb (code cells only).

Generic routing is pure and mode-independent: ``build_generic_routing`` never
imports authorization and never reads CRR evidence. CRR3 authorization is
attached only at the orchestration boundary (``main``) as separate
domain-verification metadata; it never alters routes or the generic review
list. Missing/unloadable evidence degrades every applicable verification to
``unsupported``/``evidence_unavailable`` and never aborts the stage.
"""
from crr_compare.common import REPO_ROOT, find_project_root, get_page_number, set_page_number
from crr_compare.domain import parse_domain_mode, resolve_domain_profile

# ---- cell 1 ----
import json, os, re
from collections import Counter
from pathlib import Path
from typing import Any

STEP11_VERSION = "2.3.0-generic-routing"
EXPECTED_STEP9_STAGE = "movement_and_structural_reconciliation_evidence"
EXPECTED_STEP10_STAGE = "logical_table_comparison_with_provisional_context"

NON_TABLE_GROUPS = (
    "modified",
    "modified_review",
    "duplicate_exact_review",
    "relocated",
    "deleted",
    "added",
)
MARKER_RE = re.compile(r"^(?:[A-Z]{0,3}\d+[A-Z0-9]*|[A-Z]\d+)$", re.I)
ARTICLE_PREFIX_RE = re.compile(r"^(?:Artikel|Article)\s+\d+[A-Za-z]*\b", re.I)
LIST_LABEL_RE = re.compile(
    r"^[\(\[]?(?:\d{1,3}|[ivxlcdm]{1,5}|[a-z])(?:[\)\].,;:]|\])?$", re.I
)
# How far past the last old<->new aligned element a residual candidate may
# sit before "deleted/added here" is unsupported (the other extraction may
# simply end earlier). Reading-order slots.
FRONTIER_MARGIN = 12

# ---- cell 2 ----
PROJECT_ROOT = find_project_root()
OUTPUT_DIR = PROJECT_ROOT / "output"

STEP9_PATH = OUTPUT_DIR / "comparison_candidates_with_movement.json"
STEP10_PATH = OUTPUT_DIR / "table_comparison_result.json"
OLD_DOC_PATH = OUTPUT_DIR / "old_document.json"
NEW_DOC_PATH = OUTPUT_DIR / "new_document.json"
OUTPUT_PATH = OUTPUT_DIR / "review_routing.json"


def evidence_dir() -> Path:
    """Directory holding bundled CRR3 evidence; CRR_EVIDENCE_DIR overrides test_data."""
    value = os.getenv("CRR_EVIDENCE_DIR", "").strip()
    if value:
        return Path(value).expanduser()
    return REPO_ROOT / "test_data"


AUTHORIZATION_INDEX_PATH = evidence_dir() / "crr3_amendments.json"
CRR3_XHTML_PATH = evidence_dir() / "sources" / "regulation_2024_1623_de.xhtml"

def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        value = json.load(f)
    if not isinstance(value, dict):
        raise TypeError(f"{path} must contain a JSON object.")
    return value

def save_json(value: dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write("\n")
    tmp.replace(path)

# ---- cell 3 ----
def text_of(element: dict[str, Any] | None) -> str:
    if not isinstance(element, dict):
        return ""
    for key in ("comparison_text", "normalized_text", "text"):
        value = element.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""

def token_changes(candidate: dict[str, Any]) -> list[dict[str, Any]]:
    diff = candidate.get("token_diff") or {}
    comparison = diff.get("comparison_token_diff") or {}
    return comparison.get("changes") or []


def extraction_validation_state(element: dict[str, Any] | None) -> str:
    """Classify an element's extraction metadata: 'requires_review', 'unknown', or 'ok'.

    Absent or malformed metadata is 'unknown' (never safe): only an explicit
    boolean ``requires_extraction_review`` counts as a valid verdict.
    """
    if not isinstance(element, dict):
        return "unknown"
    validation = element.get("extraction_validation")
    if not isinstance(validation, dict):
        return "unknown"
    flag = validation.get("requires_extraction_review")
    if not isinstance(flag, bool):
        return "unknown"
    return "requires_review" if flag else "ok"

def word_split_like(candidate: dict[str, Any]) -> bool:
    changes = token_changes(candidate)
    if len(changes) != 1:
        return False
    change = changes[0]
    old_tokens = change.get("old_tokens") or []
    new_tokens = change.get("new_tokens") or []
    old_join = "".join(old_tokens).casefold()
    new_join = "".join(new_tokens).casefold()
    return bool(old_join and old_join == new_join and old_tokens != new_tokens)


def wrap_artifact_like(candidate: dict[str, Any]) -> bool:
    """True when the whole diff is hyphenation/wrap-position only.

    Joins ALL changed tokens on each side across every diff operation and
    removes ONLY hyphen variants and whitespace before comparing: the sides
    must then be character-identical, which proves the diff moved a line-wrap
    hyphen/space and nothing else. Other punctuation (citations, "(4)", "=")
    still counts as a difference, so substantive edits can never qualify.
    Catches multi-operation cases that word_split_like (single-op) misses.
    """
    changes = token_changes(candidate)
    if not changes:
        return False
    old_join = "".join(
        token for change in changes for token in (change.get("old_tokens") or [])
    )
    new_join = "".join(
        token for change in changes for token in (change.get("new_tokens") or [])
    )
    strip = lambda value: re.sub(r"[-\u00ad\u2010\u2011\s]+", "", value).casefold()  # noqa: E731
    old_join, new_join = strip(old_join), strip(new_join)
    return bool(old_join) and old_join == new_join

def marker_only_like(candidate: dict[str, Any]) -> bool:
    changes = token_changes(candidate)
    if not changes or len(changes) > 2:
        return False
    changed = []
    for ch in changes:
        changed += list(ch.get("old_tokens") or [])
        changed += list(ch.get("new_tokens") or [])
    changed = [t for t in changed if str(t).strip()]
    return bool(changed) and all(MARKER_RE.match(str(t)) for t in changed)

def heading_boundary_like(candidate: dict[str, Any]) -> bool:
    old = candidate.get("old") or {}
    new = candidate.get("new") or {}
    if old.get("element_type") not in {"heading", "title"}:
        return False
    a, b = text_of(old), text_of(new)
    if not a or not b or a == b:
        return False
    shorter, longer = (a,b) if len(a) < len(b) else (b,a)
    if shorter in longer:
        fragment = longer.replace(shorter, "", 1).strip(" -–—:;,")
        return bool(fragment) and (
            ARTICLE_PREFIX_RE.match(fragment) is not None
            or len(fragment.split()) <= 4
        )
    return False
def short_text(candidate: dict[str, Any]) -> bool:
    texts = [text_of(candidate.get("old")), text_of(candidate.get("new"))]
    nonempty = [t for t in texts if t]
    return bool(nonempty) and min(len(t) for t in nonempty) < 40


def norm_text_of(element: dict[str, Any] | None) -> str:
    for key in ("normalized_text", "comparison_text", "text"):
        value = (element or {}).get(key)
        if isinstance(value, str) and value.strip():
            return " ".join(value.split()).casefold()
    return ""


def list_label_only_like(candidate: dict[str, Any]) -> bool:
    """All changed tokens on both sides are list/paragraph labels ((2), g, iii)."""
    changes = token_changes(candidate)
    if not changes:
        return False
    changed = [
        str(t)
        for ch in changes
        for t in (ch.get("old_tokens") or []) + (ch.get("new_tokens") or [])
        if str(t).strip()
    ]
    return bool(changed) and all(LIST_LABEL_RE.match(t) for t in changed)


def single_glyph_like(candidate: dict[str, Any]) -> bool:
    """Whole diff is one substituted / inserted / deleted character.

    Catches OCR/font-extraction defects (November->Novemmber, B=->P=,
    aRWA¡->aRWA;, (1)->l)) that similarity thresholds accept. Real legal
    edits are essentially never one character; routed to review, never
    suppressed, so nothing is lost.
    """
    changes = token_changes(candidate)
    if not changes or len(changes) > 3:
        return False
    strip = lambda value: re.sub(r"[-\s]+", "", value)  # noqa: E731
    old_join = strip("".join(t for ch in changes for t in (ch.get("old_tokens") or [])))
    new_join = strip("".join(t for ch in changes for t in (ch.get("new_tokens") or [])))
    if not old_join or not new_join or old_join == new_join:
        return False
    if len(old_join) == len(new_join):
        return sum(1 for a, b in zip(old_join, new_join) if a != b) == 1
    if abs(len(old_join) - len(new_join)) == 1:
        short_side, long_side = (
            (old_join, new_join) if len(old_join) < len(new_join) else (new_join, old_join)
        )
        return any(
            long_side[:i] + long_side[i + 1:] == short_side
            for i in range(len(long_side))
        )
    return False


def route_non_table(
    group: str,
    candidate: dict[str, Any],
    *,
    opposite_norm_texts: frozenset[str] = frozenset(),
    aligned_frontier: int | None = None,
) -> tuple[str, str, list[str]]:
    reasons = list(candidate.get("review_reasons") or [])
    old = candidate.get("old")
    new = candidate.get("new")

    # Only elements that exist on a side are classified: one-sided candidates
    # have a None opposite side, which must not count as unknown metadata.
    present = [element for element in (old, new) if isinstance(element, dict)]
    states = [extraction_validation_state(element) for element in present]
    source_extraction_review = "requires_review" in states
    if source_extraction_review:
        reasons.append("source_extraction_requires_review")
    elif "unknown" in states:
        reasons.append("source_extraction_validation_unknown")

    # ------------------------------------------------------------
    # Non-semantic / assignment-only cases
    # ------------------------------------------------------------

    if group == "relocated":
        return (
            "NON_SEMANTIC",
            "relocated_unchanged",
            sorted(set(reasons)),
        )

    if group == "duplicate_exact_review":
        reasons.append("duplicate_exact_assignment_ambiguous")
        return (
            "HUMAN_REVIEW",
            "duplicate_exact_assignment",
            sorted(set(reasons)),
        )

    # ------------------------------------------------------------
    # Missing, malformed, or explicitly review-required extraction
    # evidence must take precedence over artifact/structural suppression.
    # ------------------------------------------------------------
    extraction_forces_review = (
        source_extraction_review
        or "source_extraction_validation_unknown" in reasons
    )

    # ------------------------------------------------------------
    # Deterministic special-case rules
    # ------------------------------------------------------------

    if not extraction_forces_review:
        # Hyphenation/wrap-position-only differences are artifact nominations;
        # they are checked before the single-op word-split rule because this
        # covers multi-operation diffs.
        if wrap_artifact_like(candidate):
            reasons.append("hyphenation_wrap_position_only")
            # Hyphen/wrap-position differences are nominations, not proven
            # artifacts: without source-backed proof they must not be
            # deterministically suppressed. Route to human review.
            return (
                "HUMAN_REVIEW",
                "hyphenation_wrap_artifact",
                sorted(set(reasons)),
            )

        if word_split_like(candidate):
            reasons.append("possible_extraction_word_split")
            return (
                "SPECIAL_CASE_RULE",
                "possible_extraction_word_split",
                sorted(set(reasons)),
            )

        if marker_only_like(candidate):
            reasons.append("possible_marker_only_difference")
            return (
                "SPECIAL_CASE_RULE",
                "possible_marker_or_version_marker_difference",
                sorted(set(reasons)),
            )

        # Heading/title boundary differences such as
        #   "Artikel 19 <title>"  <->  "<title>"
        # are structural nominations; without source-backed proof they must not
        # be deterministically classified as structural-only.
        if heading_boundary_like(candidate):
            reasons.append("possible_structural_heading_boundary")
            # Heading/title boundary differences are nominations, not proven
            # structural-only changes: without source-backed proof they must
            # not be deterministically classified. Route to human review.
            return (
                "HUMAN_REVIEW",
                "structural_heading_boundary",
                sorted(set(reasons)),
            )

        if candidate.get("comparison_token_equivalent"):
            reasons.append(
                "comparison_token_equivalent_despite_text_difference"
            )
            return (
                "SPECIAL_CASE_RULE",
                "tokenization_neutral_difference",
                sorted(set(reasons)),
            )

        if list_label_only_like(candidate):
            reasons.append("only_list_label_tokens_differ")
            return (
                "SPECIAL_CASE_RULE",
                "list_label_only_difference",
                sorted(set(reasons)),
            )

        if single_glyph_like(candidate):
            reasons.append("single_character_difference_probable_ocr_noise")
            return (
                "SPECIAL_CASE_RULE",
                "single_glyph_difference",
                sorted(set(reasons)),
            )

    # ------------------------------------------------------------
    # Modified-review candidates
    # ------------------------------------------------------------
    #
    # These already survived matching and were explicitly withheld
    # from automatic acceptance upstream. Semantic evaluation can
    # genuinely help here.
    # ------------------------------------------------------------

    if group == "modified_review":
        return (
            "SPECIAL_CASE_LLM_OPTIONAL",
            "ambiguous_modified_pair",
            sorted(set(reasons)),
        )

    # ------------------------------------------------------------
    # One-sided ADD / DELETE candidates
    # ------------------------------------------------------------
    #
    # v2.0 over-routed every short/structural one-sided element.
    # That created 669 unnecessary LLM packets.
    #
    # Short text or heading status alone is NOT ambiguity evidence.
    # A heading such as "Artikel 105a" may simply be a real addition.
    #
    # Only positive review evidence routes a one-sided candidate to
    # optional LLM evaluation.
    # ------------------------------------------------------------

    if group in {"deleted", "added"}:
        element = old if group == "deleted" else new
        norm = norm_text_of(element)
        # Identical text exists as a residual on the OPPOSITE side: this is
        # an unresolved duplicate/relocation, never a provable add/delete.
        if norm and norm in opposite_norm_texts:
            reasons.append("identical_text_exists_on_opposite_residual_side")
            return (
                "HUMAN_REVIEW",
                "duplicate_exact_residual",
                sorted(set(reasons)),
            )
        # Beyond the aligned coverage frontier the other extraction cannot
        # confirm absence/presence; claiming deletion/addition is unsupported.
        reading_order = (element or {}).get("reading_order")
        if aligned_frontier is not None and isinstance(reading_order, int):
            if reading_order > aligned_frontier + FRONTIER_MARGIN:
                reasons.append("beyond_aligned_coverage_frontier")
                return (
                    "HUMAN_REVIEW",
                    "beyond_aligned_coverage",
                    sorted(set(reasons)),
                )
        if source_extraction_review or reasons:
            reasons.append(
                "one_sided_candidate_has_positive_review_evidence"
            )
            return (
                "SPECIAL_CASE_LLM_OPTIONAL",
                f"{group}_candidate_with_review_evidence",
                sorted(set(reasons)),
            )

        return (
            "ACCEPT_DETERMINISTIC",
            f"{group}_candidate",
            sorted(set(reasons)),
        )

    # ------------------------------------------------------------
    # Automatically accepted modified candidates
    # ------------------------------------------------------------

    if group == "modified":
        # If upstream attached explicit review evidence despite the
        # candidate living in modified, preserve that ambiguity.
        if source_extraction_review or reasons:
            return (
                "SPECIAL_CASE_LLM_OPTIONAL",
                "modified_with_review_evidence",
                sorted(set(reasons)),
            )

        return (
            "ACCEPT_DETERMINISTIC",
            "substantive_modified_candidate",
            sorted(set(reasons)),
        )

    return (
        "HUMAN_REVIEW",
        "unclassified_non_table_case",
        sorted(set(reasons)),
    )

# ---- cell 4 ----
def _frontier(movement: dict[str, Any], side_key: str) -> int | None:
    """Last reading_order on a side that participated in an old<->new match."""
    orders: list[int] = []
    for group in (
        "modified", "modified_review", "duplicate_exact_review", "relocated",
        "resegmentation_review",
    ):
        for c in movement.get(group) or []:
            value = (c.get(side_key) or {}).get("reading_order")
            if isinstance(value, int):
                orders.append(value)
    return max(orders) if orders else None


def route_table_match(match: dict[str, Any]) -> tuple[str,str,list[str]]:
    cls = match.get("classification")
    reasons = list(match.get("review_reasons") or [])
    if cls in {"UNCHANGED", "LAYOUT_EQUIVALENT"}:
        return "NON_SEMANTIC", "table_non_semantic", reasons
    if cls == "EXTRACTION_ARTIFACT_REVIEW":
        return "SPECIAL_CASE_RULE", "table_extraction_artifact", reasons
    if cls == "STRUCTURE_CHANGED_REVIEW":
        return "HUMAN_REVIEW", "table_structure_change", reasons
    if cls == "MODIFIED":
        if match.get("needs_review"):
            return "SPECIAL_CASE_LLM_OPTIONAL", "table_modified_with_review_evidence", reasons
        return "ACCEPT_DETERMINISTIC", "table_modified", reasons
    return "HUMAN_REVIEW", "unclassified_table_match", reasons


def build_generic_routing(
    movement: dict[str, Any], tables: dict[str, Any]
) -> dict[str, Any]:
    """Pure deterministic generic routing; no authorization, no file access.

    Returns ``routes`` (non-table + table), ``generic_review_list`` (routes
    needing human/optional/rule review), and the ``non_table_routes`` /
    ``table_routes`` compatibility aliases. Byte-for-byte independent of
    domain mode.
    """
    # Opposite-side residual texts: a one-sided candidate whose normalized
    # text also exists unmatched on the other side is an ambiguous duplicate,
    # not a provable add/delete.
    deleted_norm_texts = frozenset(
        t for t in (norm_text_of(c.get("old")) for c in movement.get("deleted") or []) if t
    )
    added_norm_texts = frozenset(
        t for t in (norm_text_of(c.get("new")) for c in movement.get("added") or []) if t
    )
    old_frontier = _frontier(movement, "old")
    new_frontier = _frontier(movement, "new")

    non_table_routes = []
    for group in NON_TABLE_GROUPS:
        for candidate in movement.get(group) or []:
            if group == "deleted":
                opposite, frontier = added_norm_texts, old_frontier
            elif group == "added":
                opposite, frontier = deleted_norm_texts, new_frontier
            else:
                opposite, frontier = frozenset(), None
            route, case_type, reasons = route_non_table(
                group,
                candidate,
                opposite_norm_texts=opposite,
                aligned_frontier=frontier,
            )
            non_table_routes.append({
                "route_id": f"NT-{len(non_table_routes)+1:06d}",
                "source_kind": "non_table",
                "source_group": group,
                "candidate_id": candidate.get("candidate_id"),
                "route": route,
                "case_type": case_type,
                "review_reasons": reasons,
                "old_element_id": (candidate.get("old") or {}).get("element_id"),
                "new_element_id": (candidate.get("new") or {}).get("element_id"),
                "similarity": candidate.get("similarity"),
            })

    # Evidence-only structural queues become explicit human/LLM review routes.
    for item in movement.get("resegmentation_review") or []:
        non_table_routes.append({
            "route_id": f"NT-{len(non_table_routes)+1:06d}",
            "source_kind": "structural_evidence",
            "source_group": "resegmentation_review",
            "candidate_id": item.get("candidate_id") or item.get("review_id"),
            "route": "SPECIAL_CASE_RULE",
            "case_type": "resegmentation_suspect",
            "review_reasons": list(item.get("review_reasons") or []),
            "similarity": item.get("similarity"),
        })

    for group, items, case_type in (
        ("movement_review", movement.get("movement_review") or [], "movement_block_review"),
        ("structural_split_merge_review", movement.get("structural_split_merge_review") or [], "structural_split_merge"),
        ("structural_boundary_review", movement.get("structural_boundary_review") or [], "structural_boundary"),
    ):
        for item in items:
            if group == "movement_review":
                route = "HUMAN_REVIEW"
            else:
                route = "SPECIAL_CASE_RULE"

            non_table_routes.append({
                "route_id": f"NT-{len(non_table_routes)+1:06d}",
                "source_kind": "structural_evidence",
                "source_group": group,
                "candidate_id": item.get("candidate_id") or item.get("review_id"),
                "route": route,
                "case_type": case_type,
                "review_reasons": list(item.get("review_reasons") or []),
            })

    table_routes = []
    for match in tables.get("table_matches") or []:
        route, case_type, reasons = route_table_match(match)
        table_routes.append({
            "route_id": f"TB-{len(table_routes)+1:06d}",
            "source_kind": "table_match",
            "source_group": "table_matches",
            "candidate_id": match.get("table_match_id"),
            "route": route,
            "case_type": case_type,
            "review_reasons": sorted(set(reasons)),
            "classification": match.get("classification"),
        })

    for group, case_type in (
        ("deleted_table_candidates", "deleted_table_candidate"),
        ("added_table_candidates", "added_table_candidate"),
    ):
        for table in tables.get(group) or []:
            table_routes.append({
                "route_id": f"TB-{len(table_routes)+1:06d}",
                "source_kind": "table_residual",
                "source_group": group,
                "candidate_id": table.get("logical_table_id"),
                "route": "SPECIAL_CASE_LLM_OPTIONAL",
                "case_type": case_type,
                "review_reasons": ["one_sided_table_candidate"],
            })

    for item in tables.get("unresolved_table_groups") or []:
        table_routes.append({
            "route_id": f"TB-{len(table_routes)+1:06d}",
            "source_kind": "table_review_group",
            "source_group": "unresolved_table_groups",
            "candidate_id": item.get("review_group_id"),
            "route": "HUMAN_REVIEW",
            "case_type": "unresolved_table_group",
            "review_reasons": [item.get("reason") or "unresolved_table_group"],
        })

    routes = non_table_routes + table_routes
    # The generic review queue contains only unresolved work.  Deterministic
    # SPECIAL_CASE_RULE decisions remain in ``routes`` for traceability but do
    # not consume review bandwidth.
    generic_review_list = [
        route for route in routes
        if route["route"] in {"HUMAN_REVIEW", "SPECIAL_CASE_LLM_OPTIONAL"}
    ]
    return {
        "routes": routes,
        "generic_review_list": generic_review_list,
        "non_table_routes": non_table_routes,
        "table_routes": table_routes,
    }

# ---- cell 5 ----
def attach_domain_verification(
    change: dict[str, Any],
    profile: dict[str, Any],
    verifier,
) -> dict[str, Any]:
    """Return a copy of ``change`` with ``domain_verification`` attached.

    Generic mode: the verifier is never called and the status is
    ``not_applicable``. crr3 mode: the verifier result is mapped
    ``authorized`` -> ``verified``; ``ambiguous``/``unsupported``/
    ``not_applicable`` are preserved; a missing status, a non-dict result,
    or an exception maps to ``unsupported`` with reason
    ``evidence_unavailable``. The input is never mutated.
    """
    result = dict(change)
    if (profile or {}).get("mode") != "crr3":
        result["domain_verification"] = {"status": "not_applicable"}
        return result
    try:
        verification = verifier(change) if verifier is not None else None
    except Exception:
        verification = None
    if not isinstance(verification, dict):
        result["domain_verification"] = {
            "status": "unsupported", "reason": "evidence_unavailable",
        }
        return result
    status = verification.get("status")
    if status == "authorized":
        status = "verified"
    elif status not in {"ambiguous", "unsupported", "not_applicable"}:
        result["domain_verification"] = {
            "status": "unsupported", "reason": "evidence_unavailable",
        }
        return result
    domain_verification = {"status": status}
    reason = verification.get("reason")
    if reason is not None:
        domain_verification["reason"] = reason
    elif status == "unsupported":
        domain_verification["reason"] = "evidence_unavailable"
    for key, value in verification.items():
        if key not in ("status", "reason"):
            domain_verification[key] = value
    result["domain_verification"] = domain_verification
    return result


def build_domain_verification_records(
    routes: list[dict[str, Any]],
    profile: dict[str, Any],
    verifier,
) -> list[dict[str, Any]]:
    """Return an enriched copy of every generic route with domain_verification.

    Generic mode returns ``not_applicable`` for every route without calling
    the verifier. crr3 mode calls the verifier exactly once per route;
    exceptions and malformed results degrade to ``unsupported`` with reason
    ``evidence_unavailable``. The generic routes themselves are never altered.
    """
    return [attach_domain_verification(route, profile, verifier) for route in routes]


def build_domain_verification_review(
    records: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Return the subset of verification records that require review.

    Only ``ambiguous`` and ``unsupported`` statuses need verification review;
    ``verified`` and ``not_applicable`` do not. The input ``records`` list is
    never mutated.
    """
    return [
        item
        for item in records
        if (item.get("domain_verification") or {}).get("status")
        in {"ambiguous", "unsupported"}
    ]


def crr3_verifier(movement: dict[str, Any], tables: dict[str, Any], index: dict, official_text: dict[str, str]):
    """Build the CRR3 verifier: route record -> authorization dict.

    Non-table routes are verified with ``authorize_candidate`` against the
    pinned evidence; table routes carry the ambiguous mapping (exact CRR3
    source mapping is not provable for tables); structural evidence routes
    carry no verifiable legal content (``not_applicable``).
    """
    from crr_compare.authorization import authorize_candidate

    non_table = {}
    for group in NON_TABLE_GROUPS:
        for candidate in movement.get(group) or []:
            cid = candidate.get("candidate_id")
            if cid:
                non_table[cid] = (group, candidate)

    def verify(route: dict[str, Any]) -> dict[str, Any]:
        source_kind = route.get("source_kind")
        if source_kind == "non_table":
            entry = non_table.get(route.get("candidate_id"))
            if entry is None:
                return {"status": "unsupported", "reason": "evidence_unavailable"}
            group, candidate = entry
            return authorize_candidate(group, candidate, index, official_text)
        if source_kind in {"table_match", "table_residual"}:
            return {
                "status": "ambiguous",
                "reason": "table_change_requires_exact_crr3_source_mapping",
            }
        return {"status": "not_applicable"}

    return verify


def main() -> None:
    movement = load_json(STEP9_PATH)
    tables = load_json(STEP10_PATH)

    if movement.get("comparison_stage") != EXPECTED_STEP9_STAGE:
        raise ValueError("Step 11 v2 requires the current Step 9 result.")
    if tables.get("comparison_stage") != EXPECTED_STEP10_STAGE:
        raise ValueError("Step 11 v2 requires the current Step 10 result.")

    print("Loaded Step 9 + Step 10.")

    # Orchestration boundary: resolve the domain mode and the old/new schema
    # documents; authorization evidence is loaded lazily only for crr3.
    mode = parse_domain_mode(os.getenv("CRR_DOMAIN_MODE"))
    old_doc = load_json(OLD_DOC_PATH) if OLD_DOC_PATH.exists() else {}
    new_doc = load_json(NEW_DOC_PATH) if NEW_DOC_PATH.exists() else {}
    profile = resolve_domain_profile(mode, old_doc, new_doc)

    generic = build_generic_routing(movement, tables)
    routes = generic["routes"]

    # Resolve the verifier once, then produce exactly one verification record
    # per generic route. Generic mode uses ``None`` and marks every route
    # ``not_applicable`` without calling a verifier.
    verifier = None
    evidence_loaded = None
    evidence_source = None
    if profile.get("mode") == "crr3":
        from crr_compare.authorization import load_index, official_text_from_xhtml

        evidence_loaded = True
        evidence_source = None
        try:
            index = load_index(AUTHORIZATION_INDEX_PATH)
            official_text = official_text_from_xhtml(CRR3_XHTML_PATH)
            evidence_source = index.get("source")
            verifier = crr3_verifier(movement, tables, index, official_text)
        except Exception:
            # Evidence degrades, never blocks: every applicable verification
            # becomes unsupported/evidence_unavailable.
            evidence_loaded = False
            verifier = lambda change: {"status": "unsupported", "reason": "evidence_unavailable"}  # noqa: E731

    domain_verification_records = build_domain_verification_records(
        routes, profile, verifier
    )
    domain_verification_review = build_domain_verification_review(
        domain_verification_records
    )

    status_counts = Counter()
    for record in domain_verification_records:
        status_counts[
            (record.get("domain_verification") or {}).get("status", "not_applicable")
        ] += 1
    domain_verification = {
        "enabled": profile.get("mode") == "crr3",
        "records": domain_verification_records,
        "status_counts": dict(status_counts),
    }
    if profile.get("mode") == "crr3":
        domain_verification["evidence_loaded"] = evidence_loaded
        domain_verification["evidence_source"] = evidence_source

    route_counts = Counter(item["route"] for item in routes)
    case_counts = Counter(item["case_type"] for item in routes)

    result = {
        "schema_version": "1.0.0",
        "comparison_stage": "deterministic_review_routing",
        "source_files": {
            "step9": STEP9_PATH.name,
            "step10": STEP10_PATH.name,
        },
        "processing": {
            "version": STEP11_VERSION,
            "llm_called": False,
            "matching_recomputed": False,
            "source_text_rewritten": False,
            "authoritative_hierarchy_used": False,
        },
        "statistics": {
            "route_counts": dict(route_counts),
            "case_type_counts": dict(case_counts),
            "total_routes": len(routes),
            "llm_optional_cases": route_counts["SPECIAL_CASE_LLM_OPTIONAL"],
            "human_review_cases": route_counts["HUMAN_REVIEW"],
            "llm_optional_fraction": round(
                route_counts["SPECIAL_CASE_LLM_OPTIONAL"] / max(1, len(routes)), 4
            ),
        },
        "routes": routes,
        "generic_review_list": generic["generic_review_list"],
        "domain_profile": profile,
        "domain_verification": domain_verification,
        "domain_verification_review": domain_verification_review,
        "non_table_routes": generic["non_table_routes"],
        "table_routes": generic["table_routes"],
    }

    # Every route_id must be unique.
    route_ids = [x["route_id"] for x in routes]
    assert len(route_ids) == len(set(route_ids))

    save_json(result, OUTPUT_PATH)
    print(json.dumps(result["statistics"], ensure_ascii=False, indent=2))
    print("Saved:", OUTPUT_PATH)

    # ---- cell 6 ----
    print("\n=== LLM-OPTIONAL CASE TYPES ===")
    llm_case_counts = Counter(
        item["case_type"]
        for item in routes
        if item["route"] == "SPECIAL_CASE_LLM_OPTIONAL"
    )
    print(json.dumps(dict(llm_case_counts), ensure_ascii=False, indent=2))

    print("\n=== FIRST 25 LLM-OPTIONAL ROUTES ===")
    for item in [
        x for x in routes
        if x["route"] == "SPECIAL_CASE_LLM_OPTIONAL"
    ][:25]:
        print(
            item["route_id"],
            "|",
            item["case_type"],
            "|",
            item.get("candidate_id"),
            "| reasons=",
            item.get("review_reasons"),
        )


if __name__ == "__main__":
    main()