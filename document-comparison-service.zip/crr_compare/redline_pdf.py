from __future__ import annotations
from pathlib import Path
from typing import Any
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.units import inch

_RED = "#b00020"
_STYLE = ParagraphStyle(
    "Redline", parent=getSampleStyleSheet()["BodyText"], fontSize=10,
    leading=14, alignment=TA_LEFT, spaceAfter=6)
_ID_STYLE = ParagraphStyle(
    "Id", parent=_STYLE, fontName="Helvetica-Bold", spaceAfter=2)

def _escape(text: str) -> str:
    return str(text or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

def _old(text: str) -> str:
    return f'<strike color="{_RED}">{_escape(text)}</strike>'

def _new(text: str) -> str:
    return f'<u><font color="{_RED}">{_escape(text)}</font></u>'

def _para(markup: str, style: ParagraphStyle) -> Paragraph:
    return Paragraph(markup, style)

def _proof_line(change: dict[str, Any]) -> str:
    resolution = change.get("resolution") or {}
    parts: list[str] = []
    status = resolution.get("status")
    if status:
        parts.append(f"status={_escape(status)}")
    if resolution.get("needs_review"):
        parts.append("needs_review=True")
    reasons = change.get("review_reasons")
    if isinstance(reasons, list) and reasons:
        parts.append(f"reasons={_escape('|'.join(str(r) for r in reasons[:3]))}")
    elif reasons:
        parts.append(f"reasons={_escape(str(reasons))}")
    evidence = change.get("evidence")
    if evidence:
        parts.append("evidence=yes")
    return " ".join(parts)

def render_pdf(comparison: dict[str, Any], output_path: Path) -> Path:
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(str(output_path), pagesize=letter,
                            rightMargin=0.75*inch, leftMargin=0.75*inch,
                            topMargin=0.75*inch, bottomMargin=0.75*inch)
    story: list[Any] = [_para("Document Comparison Redline", _ID_STYLE), Spacer(1, 0.2*inch)]

    for change in comparison.get("changes", []):
        cid = change.get("change_id", "?")
        ctype = change.get("change_type", "CHANGED")
        old_text = (change.get("old") or {}).get("text", "")
        new_text = (change.get("new") or {}).get("text", "")
        status = (change.get("resolution") or {}).get("status", "review")
        story.append(_para(f"[{_escape(cid)}] {_escape(ctype)} ({_escape(status)})", _ID_STYLE))
        story.append(_para(_old(f"old: {old_text}"), _STYLE))
        story.append(_para(_new(f"new: {new_text}"), _STYLE))
        proof = _proof_line(change)
        if proof:
            story.append(_para(proof, _STYLE))
        story.append(Spacer(1, 0.1*inch))

    for table in comparison.get("table_changes", []):
        cid = table.get("table_change_id", "?")
        ctype = table.get("change_type", "CHANGED")
        classification = table.get("classification", "")
        old_meta = table.get("old") or {}
        new_meta = table.get("new") or {}
        dims = f"old={old_meta.get('row_count','?')}x{old_meta.get('column_count','?')} new={new_meta.get('row_count','?')}x{new_meta.get('column_count','?')}"
        story.append(_para(f"[{_escape(cid)}] table {_escape(ctype)} {_escape(classification)} {_escape(dims)}", _ID_STYLE))
        for cell in table.get("cell_changes", []):
            old_cell = (cell.get("old") or {}).get("text", "")
            new_cell = (cell.get("new") or {}).get("text", "")
            story.append(_para(_old(f"old cell: {old_cell}"), _STYLE))
            story.append(_para(_new(f"new cell: {new_cell}"), _STYLE))
        proof = _proof_line(table)
        if proof:
            story.append(_para(proof, _STYLE))
        story.append(Spacer(1, 0.1*inch))

    for item in comparison.get("review_queue", []):
        review_status = (item.get("resolution") or {}).get("status", "review")
        story.append(_para(f"[{_escape(item.get('review_id', '?'))}] review: {_escape(review_status)}", _STYLE))

    doc.build(story)
    return output_path
