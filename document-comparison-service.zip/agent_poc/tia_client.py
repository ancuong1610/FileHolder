from __future__ import annotations

from typing import Any


def response_text(value: Any) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        for key in ("text", "content", "response", "output_text", "answer"):
            if isinstance(value.get(key), str):
                return value[key]
    return str(value)


class TiaTextClient:
    """Thin adapter matching the working Stage-13 TIA integration."""

    def __init__(self, api_key: str) -> None:
        if not api_key:
            raise RuntimeError("Missing TIA_API_KEY. Put it in agent_poc/.env or the process environment.")
        self.api_key = api_key

    def invoke(self, prompt: str, system_message: str) -> str:
        import bbk_ai_hub_sdk

        value = bbk_ai_hub_sdk.invoke_text_api(self.api_key, prompt, system_message)
        return response_text(value)

