import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
import fitz
from crr_compare.redline_pdf import render_pdf

COMPARISON = {
    "changes": [{
        "change_id": "E-001",
        "change_type": "MODIFIED",
        "old": {"text": "old value"},
        "new": {"text": "new value"},
        "resolution": {"status": "accepted", "needs_review": False},
    }],
    "table_changes": [{
        "table_change_id": "T-001",
        "change_type": "MODIFIED",
        "classification": "cell_change",
        "old": {"logical_table_id": "T1", "row_count": 2, "column_count": 3},
        "new": {"logical_table_id": "T1", "row_count": 2, "column_count": 3},
        "cell_changes": [
            {"old": {"text": "1"}, "new": {"text": "2"}},
        ],
    }],
    "review_queue": [{"review_id": "E-001", "resolution": {"status": "review"}}],
}

class RedlinePdfTest(unittest.TestCase):
    def test_pdf_header(self):
        with TemporaryDirectory() as d:
            self.assertTrue(render_pdf(COMPARISON, Path(d) / "redline.pdf").read_bytes().startswith(b"%PDF-"))
    def test_ids_and_text_extractable(self):
        with TemporaryDirectory() as d:
            with fitz.open(render_pdf(COMPARISON, Path(d) / "redline.pdf")) as doc:
                text = "".join(page.get_text() for page in doc)
        for token in ("E-001", "T-001", "new value"):
            self.assertIn(token, text)
    def test_red_markup_drawings_present(self):
        with TemporaryDirectory() as d:
            with fitz.open(render_pdf(COMPARISON, Path(d) / "redline.pdf")) as doc:
                page = doc[0]
                texts = page.get_text("dict")["blocks"]
                colors = {span.get("color") for block in texts for line in block.get("lines", []) for span in line.get("spans", [])}
                drawings = page.get_drawings()
        # ReportLab Paragraph markup renders as red text spans; underline/strike may also appear as drawings.
        self.assertTrue(any(c is not None and c != 0 for c in colors), colors)
        self.assertTrue(len(drawings) > 0 or any(c is not None and c != 0 for c in colors))
    def test_empty_comparison_still_renders(self):
        with TemporaryDirectory() as d:
            self.assertTrue(render_pdf({}, Path(d) / "redline.pdf").read_bytes().startswith(b"%PDF-"))
    def test_long_text_spans_pages(self):
        comparison = {"changes": [{
            "change_id": f"E-{i:03d}",
            "change_type": "MODIFIED",
            "old": {"text": "x" * 400},
            "new": {"text": "y" * 400},
            "resolution": {"status": "accepted", "needs_review": False},
        } for i in range(1, 40)]}
        with TemporaryDirectory() as d:
            with fitz.open(render_pdf(comparison, Path(d) / "redline.pdf")) as doc:
                page_count = doc.page_count
        self.assertGreaterEqual(page_count, 2)

if __name__ == "__main__":
    unittest.main()
