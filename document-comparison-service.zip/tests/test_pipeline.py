import importlib
import json
import os
import random
import subprocess
import sys
import unittest
from pathlib import Path

from crr_compare.evaluate import run_identity, run_mutation
from crr_compare.mutations import _mutate_one_text

ROOT = Path(__file__).resolve().parents[1]


class BootstrapTest(unittest.TestCase):
    def test_python_version(self):
        self.assertGreaterEqual(sys.version_info[:2], (3, 10))

    def test_packages_import(self):
        for name in ("crr_compare", "agent_poc"):
            importlib.import_module(name)

    def test_required_tree(self):
        for rel in ("requirements.txt", ".env.example", "input/.gitkeep",
                    "test_data/fixtures_general/crr3/old_di_raw.json",
                    "test_data/fixtures_general/crr3/new_di_raw.json"):
            self.assertTrue((ROOT / rel).exists(), rel)

    def test_fixture_present(self):
        self.assertTrue([p for p in (ROOT / "test_data" / "fixtures_general").rglob("*")])

    def test_clean_tree(self):
        banned_dirs = {"private", "runtime", "cache"}
        ignored_roots = {".venv", "venv", "workspace", "__pycache__"}
        found = {
            p.name for p in ROOT.rglob("*")
            if p.is_dir()
            and not any(part in ignored_roots for part in p.relative_to(ROOT).parts)
        }
        self.assertFalse(banned_dirs & found, banned_dirs & found)

    def test_no_bbk_in_public_requirements(self):
        req = (ROOT / "requirements.txt").read_text()
        self.assertNotIn("bbk_ai_hub_sdk", req)


class BenchmarkTest(unittest.TestCase):
    def test_identity_zero_changes(self):
        result = run_identity(ROOT / "workspace")
        self.assertTrue(result["passed"], result)
        self.assertEqual(result["element_changes"], 0)
        self.assertEqual(result["table_changes"], 0)

    def test_mutation_summary_passes(self):
        result = run_mutation(ROOT / "workspace", seed=42)
        self.assertTrue(result["passed"], result)
        self.assertIn("summary", result)
        for category in ("modify", "delete", "insert", "move_block", "table_cell", "noise_hyphenation"):
            self.assertIn(category, result["summary"], category)

    def test_cli_writes_report_list_and_exits_zero(self):
        proc = subprocess.run([sys.executable, "-m", "crr_compare", "eval", "--root", "workspace"],
            cwd=ROOT, capture_output=True, text=True, env={**os.environ, "CRR_RUN_LLM": "mock", "CRR_DOMAIN_MODE": "generic"})
        self.assertEqual(proc.returncode, 0, proc.stderr)
        report = json.loads((ROOT / "workspace" / "eval" / "eval_report.json").read_text())
        self.assertIsInstance(report, list)
        self.assertTrue(any(entry.get("case") == "identity" for entry in report))
        self.assertTrue(any(entry.get("case") == "mutation" for entry in report))


class MutationUnitTest(unittest.TestCase):
    def test_single_word_text_is_mutated(self):
        """Regression: a single eligible word must be mutable despite the 15% lead-in guard."""
        new_text, changed = _mutate_one_text("Standard", random.Random(42))
        self.assertTrue(changed)
        self.assertNotEqual(new_text, "Standard")


if __name__ == "__main__":
    unittest.main()
